# Presence detector v3

`cnn.pt` contains the original trained PresenceCNN weights. SHA-256: 38155ab633b1784f02adb58b1475afaa9af75a17f1461d76b7136580e4c341ab. `selected_model.pt` records the selected model name and threshold. No training examples or survey coordinates are included.
