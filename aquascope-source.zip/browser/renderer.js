/* PNGs are rendered from numerical samples; annotations never alter stored SGY. */
(function(root,factory){const value=factory(root.GprEngine||(typeof require==='function'?require('./engine.js'):null));if(typeof module==='object'&&module.exports)module.exports=value;else root.GprRenderer=value})(typeof self!=='undefined'?self:globalThis,function(core){
 'use strict';
 const canvas=(w,h)=>{if(typeof OffscreenCanvas!=='undefined')return new OffscreenCanvas(w,h);const c=document.createElement('canvas');c.width=w;c.height=h;return c};
 async function png(image){
  const {values,width,height,half,label}=image,finite=values.filter(Number.isFinite),limit=image.amplitudeLimit||core.quantileAbs(finite,.99)||1;
  const pixels=new Uint8ClampedArray(width*height*4);
  for(let i=0;i<values.length;i++){
   const value=Number.isFinite(values[i])?Math.floor((Math.max(-1,Math.min(1,values[i]/limit))+1)*127.5):42;
   pixels[i*4]=pixels[i*4+1]=pixels[i*4+2]=value;pixels[i*4+3]=255;
  }
  const small=canvas(width,height),a=small.getContext('2d');a.putImageData(new ImageData(pixels,width,height),0,0);
  const out=canvas(1100,470),ctx=out.getContext('2d');ctx.fillStyle='#242024';ctx.fillRect(0,0,1100,470);ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';ctx.drawImage(small,0,28,1100,400);
  ctx.font='14px sans-serif';ctx.fillStyle='#eee7e8';ctx.fillText(label||'',12,19,1076);
  if(image.metalMask){ctx.fillStyle='#f5b65c';for(let c=0;c<width;c++)if(image.metalMask[c])ctx.fillRect(c/width*1100,28,Math.max(1,1100/width),6)}
  const position=offset=>Math.round((offset+half)/(2*half)*1099);
  if(Number.isFinite(image.blue)){ctx.strokeStyle='#70b9f2';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(position(image.blue),28);ctx.lineTo(position(image.blue),428);ctx.stroke()}
  if(Number.isFinite(image.green)&&Math.abs(image.green)<=half){ctx.strokeStyle='#20c785';ctx.lineWidth=image.dashed?3:2;ctx.setLineDash(image.dashed?[10,6]:[]);ctx.beginPath();ctx.moveTo(position(image.green),28);ctx.lineTo(position(image.green),428);ctx.stroke();ctx.setLineDash([])}
  ctx.strokeStyle='#c9bfc2';ctx.fillStyle='#eee7e8';ctx.lineWidth=1;
  for(let i=0;i<5;i++){
   const value=-half+i*half/2,x=position(value),text=image.axisLabels?image.axisLabels[i]:(value===0?'0 m':(value>0?'+':'')+value+' m');
   ctx.beginPath();ctx.moveTo(x,428);ctx.lineTo(x,435);ctx.stroke();const w=ctx.measureText(text).width;ctx.fillText(text,Math.max(2,Math.min(1097-w,x-w/2)),452);
  }
  if(out.convertToBlob)return out.convertToBlob({type:'image/png'});
  return new Promise((resolve,reject)=>out.toBlob(blob=>blob?resolve(blob):reject(Error('Could not create a PNG image.')),'image/png'));
 }
 return {png};
});
