/* Data-integrity and inference checks for explicit trace muting. */
const assert=require('node:assert/strict'),core=require('./engine.js');
function fixture(ext=0){
 const n=301,ns=8,offset=3600+ext*3200,stride=240+ns*4,bytes=new Uint8Array(offset+n*stride),v=new DataView(bytes.buffer);
 bytes.fill(32,0,3200);v.setUint16(3220,ns);v.setUint16(3224,2);v.setInt16(3504,ext);
 for(let i=0;i<n;i++){const p=offset+i*stride;v.setInt16(p+70,-1000);v.setInt32(p+72,800000000+40*i);v.setInt32(p+76,820000000);v.setUint16(p+114,ns);for(let r=0;r<ns;r++)v.setInt32(p+240+r*4,(i>=140&&i<=145?100:10)*(r%2?-1:1))}
 return bytes;
}
(async()=>{
 for(const ext of [0,2]){
  const original=fixture(ext),copy=original.slice(),sgy=core.parseSgy(original),draft=core.metallicMask(sgy,3);
  assert.deepEqual(draft.report.ranges_1based_inclusive,[[141,146]]);assert.equal(draft.report.muted_traces,6);
  assert.equal(core.metallicMask(sgy,10).report.muted_traces,0,'Exact threshold equality must not flag a trace');
  assert.equal(core.applyMetalMute(sgy,{metal_mute:false}),sgy);
  const noSelection=core.applyMetalMute(sgy,{metal_mute:true});assert.equal(noSelection.meta.metal_mute.muted_traces,0);assert.deepEqual(noSelection.samples,sgy.samples);
  const chosen=core.selectedMetalMask(sgy.n,[[1,1],[141,144],[143,146],[301,301]]),output=core.mutedSgyBytes(original,sgy,chosen.mask),parsed=core.parseSgy(output);
  assert.deepEqual(chosen.report.ranges_1based_inclusive,[[1,1],[141,146],[301,301]]);assert.equal(chosen.report.muted_traces,8);
  assert.deepEqual(original,copy,'Original byte buffer must never change');assert.equal(output.length,original.length);assert.equal(parsed.n,sgy.n);assert.deepEqual(parsed.x,sgy.x);assert.deepEqual(parsed.y,sgy.y);
  for(let i=0;i<output.length;i++){const rel=i-sgy.recordOffset,trace=Math.floor(rel/sgy.traceStride),sampleOffset=rel%sgy.traceStride;const muted=rel>=0&&trace<sgy.n&&chosen.mask[trace]&&sampleOffset>=240;assert.equal(output[i],muted?0:original[i],`Unexpected byte change ${i}`)}
  for(const invalid of [[[0,1]],[[3,2]],[[1,302]],[[1.5,2]],[[1]],null])assert.throws(()=>core.selectedMetalMask(sgy.n,invalid));
  const processed=core.applyMetalMute(sgy,{metal_mute:true,metal_ranges:chosen.report.ranges_1based_inclusive});assert.deepEqual(processed.samples,parsed.samples);assert.notEqual(processed.samples,sgy.samples);
 }
 const zero=core.parseSgy(fixture());zero.samples.fill(0);assert.equal(core.metallicMask(zero,3).report.muted_traces,0);assert.throws(()=>core.metallicMask(zero,NaN));
 const raw=fixture(),file={id:'test',name:'validation-4.SGY',size:raw.length,file:{lastModified:123,arrayBuffer:async()=>raw.buffer}},options={step_m:.5,merge_m:4,spacing_m:.04,threshold:.9,batch_size:8,metal_mute:true,metal_ranges_by_file:{[core.fileKey(file)]:[[141,161]]}};
 const result=await core.scanFiles([file],options,{presence:async(v,n)=>Float32Array.from({length:n},()=>20),localizer:async(v,n)=>{const a=new Float32Array(n*193);for(let i=0;i<n;i++)a[i*193+96]=1;return a}},()=>{});
 assert.equal(result.summary.muted_traces,21);assert(result.files[0].skipped_muted_center_windows>0);assert(result.candidates.every(r=>r.trace_1based<141||r.trace_1based>161));
 console.log(JSON.stringify({tests:'metallic mute integrity, explicit selection, extended headers, inference masking',all_passed:true,original_preserved:true,headers_and_xy_preserved:true}));
})().catch(e=>{console.error(e);process.exitCode=1});
