/* Runs the exact browser WASM runtime under Node against local, private fixtures. */
const fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url'),assert=require('node:assert/strict');
const core=require('./engine.js'),ort=require('./vendor/onnxruntime/ort.wasm.min.js');
const qa=path.resolve(process.argv[2]||'');
const maxError=(a,b)=>{assert.equal(a.length,b.length);let max=0;for(let i=0;i<a.length;i++)if(Number.isFinite(a[i])||Number.isFinite(b[i]))max=Math.max(max,Math.abs(a[i]-b[i]));return max};
const floats=name=>{const b=fs.readFileSync(path.join(qa,name));return new Float32Array(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength))};
(async()=>{
 const reference=JSON.parse(fs.readFileSync(path.join(qa,'browser_reference.json'))),raw=fs.readFileSync(path.join(qa,'private_validation-4.SGY')),sgy=core.parseSgy(raw);
 assert.equal(sgy.meta.samples_per_trace,reference.meta.samples_per_trace);assert(Math.abs(sgy.spacing-reference.meta.spacing_m)<1e-12);
 const inputs=new Float32Array(reference.selected_centers.length*128*193);reference.selected_centers.forEach((c,i)=>inputs.set(core.preprocess(sgy,c,reference.half),i*128*193));
 const preprocessingError=maxError(inputs,floats('preprocess_reference.f32'));
 assert(preprocessingError<1e-4,`Preprocessing error ${preprocessingError}`);
 ort.env.wasm.numThreads=1;ort.env.wasm.wasmPaths=pathToFileURL(path.join(__dirname,'vendor','onnxruntime')+path.sep).href;
 const manifest=JSON.parse(fs.readFileSync(path.join(__dirname,'models','manifest.json')));
 const presence=await ort.InferenceSession.create(new Uint8Array(fs.readFileSync(path.join(__dirname,'models',manifest.presence.file))),{executionProviders:['wasm']});
 const localizer=await ort.InferenceSession.create(new Uint8Array(fs.readFileSync(path.join(__dirname,'models',manifest.localizer.file))),{executionProviders:['wasm']});
 const run=async(session,values,batch)=>Object.values(await session.run({input:new ort.Tensor('float32',values,[batch,1,128,193])}))[0].data;
 const localValues=await run(localizer,inputs,reference.selected_centers.length),expectedLocal=floats('localizer_reference.f32');
 const localizerError=maxError(localValues,expectedLocal);assert(localizerError<1e-3,`Localizer error ${localizerError}`);
 for(let i=0;i<reference.selected_centers.length;i++){
  const argmax=a=>{let k=0;for(let j=1;j<a.length;j++)if(a[j]>a[k])k=j;return k};
  assert.equal(argmax(localValues.subarray(i*193,(i+1)*193)),argmax(expectedLocal.subarray(i*193,(i+1)*193)));
 }
 const result=await core.scanFiles([{id:'validation',name:'validation-4.SGY',file:{arrayBuffer:async()=>raw.buffer.slice(raw.byteOffset,raw.byteOffset+raw.byteLength)}}],{spacing_m:.04,step_m:.5,merge_m:4,threshold:manifest.threshold,batch_size:8},{presence:(v,n)=>run(presence,v,n),localizer:(v,n)=>run(localizer,v,n),checkpoint:manifest.checkpoint_sha256});
 const scoreError=maxError(result.scores[0].logit,reference.logs);assert(scoreError<1e-3,`Score error ${scoreError}`);
 assert.equal(result.candidates.length,reference.candidates.length);
 result.candidates.forEach((r,i)=>{const expected=reference.candidates[i];for(const field of ['trace_1based','window_center_trace_1based','supporting_observations','channel','x','y'])assert.equal(r[field],expected[field],field)});
 const track=core.trackGeometry(sgy),projection=core.project(track,[sgy.x[600],sgy.y[600]],600),window=core.physicalWindow(sgy,track,projection,4);
 assert.equal(projection.nearest+1,reference.projection.trace);assert(Math.abs(projection.distance-reference.projection.distance)<1e-9);
 const windowError=maxError(window.values,floats('physical_window_reference.f32'));assert(windowError<1e-3,`Physical window error ${windowError}`);
 const report={runtime:'ONNX Runtime Web 1.31.1 / WASM, one thread',preprocessing_max_abs_error:preprocessingError,presence_logit_max_abs_error:scoreError,localizer_max_abs_error:localizerError,localizer_columns_identical:true,candidate_count:result.candidates.length,scored_windows:result.summary.scored_windows,candidate_centers_identical:true,candidate_xy_identical:true,physical_window_max_abs_error:windowError,all_checks_passed:true};
 fs.writeFileSync(path.join(qa,'onnx_browser_numerical_parity.json'),JSON.stringify(report,null,2));
 console.log(JSON.stringify(report,null,2));
})().catch(error=>{console.error(error);process.exitCode=1});
