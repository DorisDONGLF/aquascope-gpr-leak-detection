/* CSV, Geolitix DXF, 2D Shapefile and ZIP generation entirely on-device. */
(function(root,factory){const value=factory();if(typeof module==='object'&&module.exports)module.exports=value;else root.GprExports=value})(typeof self!=='undefined'?self:globalThis,function(){
 'use strict';
 const encoder=new TextEncoder(),bytes=value=>typeof value==='string'?encoder.encode(value):value;
 const FIELDS=['candidate_id','review_label','reviewer','notes','name','profile','channel','trace_1based','window_center_trace_1based','x','y','distance_to_known_m','near_known','logit','signal_score','samples_per_trace','supporting_observations','supporting_channels','supporting_swaths','spacing_m','localizer_shift_m','reviewed_at'];
 const DBF=[['CAND_ID','candidate_id','C',24,0],['REVIEW','review_label','C',24,0],['REVIEWER','reviewer','C',100,0],['NOTES','notes','C',254,0],['SGY_NAME','name','C',254,0],['PROFILE','profile','C',254,0],['CHANNEL','channel','N',8,0],['TRACE','trace_1based','N',12,0],['X','x','N',24,9],['Y','y','N',24,9],['LOGIT','logit','N',20,8],['SCORE','signal_score','N',20,15],['SUPPORT','supporting_observations','N',10,0],['CHANNELS','supporting_channels','C',254,0],['SWATHS','supporting_swaths','N',10,0],['NSAMPLES','samples_per_trace','N',10,0],['REVIEWED','reviewed_at','C',40,0]];
 function selectRows(job,mode='all',ids){
  if(job.status!=='done')throw Error('Export is available after detection completes.');
  let rows=job.candidates;
  if(mode==='ids'){
   if(!Array.isArray(ids)||!ids.length||ids.some(id=>typeof id!=='string'))throw Error('The current selection or filter is empty.');
   const wanted=new Set(ids),valid=new Set(rows.map(r=>r.candidate_id));if(ids.some(id=>!valid.has(id)))throw Error('The selection contains candidate IDs that do not exist.');
   rows=rows.filter(r=>wanted.has(r.candidate_id));
  }else if(mode!=='all')throw Error('Invalid export scope.');
  if(!rows.length)throw Error('No candidates to export.');return rows;
 }
 function csv(rows){
  const quote=v=>'"'+String(Array.isArray(v)?v.join(','):v===null||v===undefined?'':v).replace(/"/g,'""')+'"';
  return '\ufeff'+[FIELDS,...rows.map(r=>FIELDS.map(k=>r[k]))].map(r=>r.map(quote).join(',')).join('\r\n')+'\r\n';
 }
 function requireXY(rows){const missing=rows.filter(r=>!Number.isFinite(r.x)||!Number.isFinite(r.y));if(missing.length)throw Error(`${missing.length} candidates have no valid XY. Use CSV or filter to candidates with coordinates.`)}
 function dxf(rows){
  requireXY(rows);const tags=[],p=(...a)=>tags.push(...a.map(String));
  p(0,'SECTION',2,'HEADER',9,'$ACADVER',1,'AC1009',9,'$PDMODE',70,3,9,'$PDSIZE',40,.4,0,'ENDSEC',0,'SECTION',2,'TABLES',0,'TABLE',2,'LTYPE',70,1,0,'LTYPE',2,'CONTINUOUS',70,0,3,'Solid line',72,65,73,0,40,0,0,'ENDTAB',0,'TABLE',2,'LAYER',70,3);
  for(const [name,color] of [['0',7],['AI_CANDIDATES',1],['AI_LABELS',7]])p(0,'LAYER',2,name,70,0,62,color,6,'CONTINUOUS');
  p(0,'ENDTAB',0,'TABLE',2,'STYLE',70,1,0,'STYLE',2,'STANDARD',70,0,40,0,41,1,50,0,71,0,42,1,3,'txt',4,'',0,'ENDTAB',0,'ENDSEC',0,'SECTION',2,'ENTITIES');
  for(const r of rows){
   const x=r.x,y=r.y,id=r.candidate_id;if(!/^[\x20-\x7e]+$/.test(id))throw Error('DXF candidate IDs must be single-line ASCII.');
   p(0,'POINT',8,'AI_CANDIDATES',10,x.toFixed(9),20,y.toFixed(9),30,0);
   for(const points of [[[x-.35,y],[x+.35,y]],[[x,y-.35],[x,y+.35]]]){
    p(0,'POLYLINE',8,'AI_CANDIDATES',66,1,10,0,20,0,30,0,70,0);
    for(const [vx,vy] of points)p(0,'VERTEX',8,'AI_CANDIDATES',10,vx.toFixed(9),20,vy.toFixed(9),30,0);
    p(0,'SEQEND',8,'AI_CANDIDATES');
   }
   p(0,'TEXT',8,'AI_LABELS',10,(x+.5).toFixed(9),20,(y+.5).toFixed(9),30,0,40,.6,1,id,50,0,7,'STANDARD');
  }
  p(0,'ENDSEC',0,'EOF');return tags.join('\r\n')+'\r\n';
 }
 function utf8Prefix(text,width){let b=encoder.encode(text).slice(0,width);for(;;){try{new TextDecoder('utf-8',{fatal:true}).decode(b);return b}catch{b=b.slice(0,-1)}}}
 function dbf(rows){
  const now=new Date(),headerLength=33+32*DBF.length,recordLength=1+DBF.reduce((sum,f)=>sum+f[3],0),out=new Uint8Array(headerLength+rows.length*recordLength+1),view=new DataView(out.buffer);
  out[0]=3;out[1]=now.getFullYear()-1900;out[2]=now.getMonth()+1;out[3]=now.getDate();view.setUint32(4,rows.length,true);view.setUint16(8,headerLength,true);view.setUint16(10,recordLength,true);
  DBF.forEach(([name,key,type,width,decimals],i)=>{const p=32+i*32;out.set(encoder.encode(name),p);out[p+11]=type.charCodeAt(0);out[p+16]=width;out[p+17]=decimals});out[headerLength-1]=13;
  rows.forEach((row,index)=>{
   let p=headerLength+index*recordLength;out[p++]=32;
   for(const [name,key,type,width,decimals] of DBF){
    const value=row[key];let data;
    if(type==='N'){
     if(value===null||value===undefined)data=new Uint8Array();
     else {if(!Number.isFinite(value))throw Error(`${row.candidate_id}: ${key} is not a finite number.`);data=encoder.encode(decimals?value.toFixed(decimals):String(Math.trunc(value)))}
     if(data.length>width)throw Error(`DBF field ${key} exceeds its numeric width. Use CSV.`);
     out.fill(32,p,p+width);out.set(data,p+width-data.length);
    }else {const text=Array.isArray(value)?value.join(','):String(value??'');data=utf8Prefix(text.replace(/\0/g,''),width);out.fill(32,p,p+width);out.set(data,p)}
    p+=width;
   }
  });out[out.length-1]=26;return out;
 }
 function shpFiles(rows){
  requireXY(rows);const xs=rows.map(r=>r.x),ys=rows.map(r=>r.y),bounds=[Math.min(...xs),Math.min(...ys),Math.max(...xs),Math.max(...ys),0,0,0,0];
  function header(out){const v=new DataView(out.buffer);v.setInt32(0,9994);v.setInt32(24,out.byteLength/2);v.setInt32(28,1000,true);v.setInt32(32,1,true);bounds.forEach((value,i)=>v.setFloat64(36+i*8,value,true));return v}
  const shp=new Uint8Array(100+rows.length*28),shx=new Uint8Array(100+rows.length*8),a=header(shp),b=header(shx);
  rows.forEach((r,i)=>{const p=100+i*28;a.setInt32(p,i+1);a.setInt32(p+4,10);a.setInt32(p+8,1,true);a.setFloat64(p+12,r.x,true);a.setFloat64(p+20,r.y,true);b.setInt32(100+i*8,50+i*14);b.setInt32(104+i*8,10)});
  return {'candidates.shp':shp,'candidates.shx':shx,'candidates.dbf':dbf(rows),'candidates.cpg':'UTF-8','field_mapping.json':JSON.stringify(Object.fromEntries(DBF.map(f=>[f[0],f[1]])),null,2),'attributes.json':JSON.stringify(rows,null,2)};
 }
 const crcTable=Uint32Array.from({length:256},(_,i)=>{let x=i;for(let bit=0;bit<8;bit++)x=x&1?0xedb88320^(x>>>1):x>>>1;return x>>>0});
 function crc32(data){let crc=0xffffffff;for(let i=0;i<data.length;i++)crc=crcTable[(crc^data[i])&255]^(crc>>>8);return (crc^0xffffffff)>>>0}
 async function zipStore(files){
  const contents=[],directory=[];let offset=0,count=0,centralSize=0;
  for(const [name,input] of Object.entries(files)){
   const filename=encoder.encode(name),data=input instanceof Blob?new Uint8Array(await input.arrayBuffer()):bytes(input),crc=crc32(data);
   if(data.length>0xffffffff||offset>0xffffffff)throw Error('This ZIP exceeds the supported 4 GB limit. Export a smaller selection.');
   const local=new Uint8Array(30+filename.length),v=new DataView(local.buffer);v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x800,true);v.setUint32(14,crc,true);v.setUint32(18,data.length,true);v.setUint32(22,data.length,true);v.setUint16(26,filename.length,true);local.set(filename,30);contents.push(local,data);
   const central=new Uint8Array(46+filename.length),c=new DataView(central.buffer);c.setUint32(0,0x02014b50,true);c.setUint16(4,20,true);c.setUint16(6,20,true);c.setUint16(8,0x800,true);c.setUint32(16,crc,true);c.setUint32(20,data.length,true);c.setUint32(24,data.length,true);c.setUint16(28,filename.length,true);c.setUint32(42,offset,true);central.set(filename,46);directory.push(central);centralSize+=central.length;offset+=local.length+data.length;count++;
  }
  if(count>65535)throw Error('Too many files for this ZIP export.');
  const end=new Uint8Array(22),e=new DataView(end.buffer);e.setUint32(0,0x06054b50,true);e.setUint16(8,count,true);e.setUint16(10,count,true);e.setUint32(12,centralSize,true);e.setUint32(16,offset,true);
  return new Blob([...contents,...directory,end],{type:'application/zip'});
 }
 async function makeExport(job,request){
  let formats=request.formats??['csv'];if(!Array.isArray(formats)||!formats.length||formats.some(f=>!['csv','dxf','shp'].includes(f)))throw Error('Select CSV, Geolitix DXF or Shapefile.');formats=[...new Set(formats)];
  const rows=selectRows(job,request.mode||'all',request.candidate_ids),wkt=String(request.crs_wkt||'').trim(),crs=String(request.crs_name||'').trim().slice(0,200),stem=`gpr_${job.id.slice(0,8)}_${rows.length}_points`;
  if(wkt&&(wkt.length>20000||!['PROJCS[','GEOGCS[','PROJCRS[','GEOGCRS['].some(p=>wkt.startsWith(p))))throw Error('Invalid CRS WKT. Supply a complete projected or geographic CRS WKT.');
  if(formats.length===1&&formats[0]==='csv')return {blob:new Blob([csv(rows)],{type:'text/csv;charset=utf-8'}),filename:stem+'.csv',contentType:'text/csv;charset=utf-8'};
  const files={};if(formats.includes('csv'))files['candidates.csv']=csv(rows);if(formats.includes('dxf'))files['geolitix_candidates.dxf']=dxf(rows);if(formats.includes('shp')){Object.assign(files,shpFiles(rows));if(wkt)files['candidates.prj']=wkt}
  files['manifest.json']=JSON.stringify({job_id:job.id,title:job.title,point_count:rows.length,candidate_ids:rows.map(r=>r.candidate_id),formats,exported_at:new Date().toISOString(),model:job.summary?.model,checkpoint_sha256:job.summary?.checkpoint_sha256,source_xy_preserved:true,coordinate_transform_applied:false,crs_name:crs||'Unspecified source XY',crs_wkt:wkt||null,depth_predicted:false,scope:request.scope_description||request.mode||'all',processing_location:'visitor browser',sgy_preprocessing:{metal_mute_enabled:!!job.summary?.metal_mute_enabled,mode:job.summary?.metal_mute_mode||'raw',threshold:job.summary?.metal_mute_threshold??null,files:(job.files||[]).filter(f=>f.metal_mute).map(f=>({name:f.name,...f.metal_mute}))}},null,2);
  files['README.txt']=`AquaScope GPR · ${rows.length} points\nRaw SGY XY is preserved; no coordinate transformation is applied.\nCRS: ${crs||'Unspecified; confirm before GIS import.'}\nImport geolitix_candidates.dxf through Geolitix DXF Base Maps with the matching source CRS.\nSHP is 2D POINT; keep SHP/SHX/DBF/CPG and PRJ (when supplied) together.\nDBF text can be shortened to its byte limit; attributes.json preserves full text.\nDXF Z=0 is a 2D placeholder, not depth. Crosses are display symbols.\nModel outputs rank similarity; they are not calibrated leak probabilities.\nReview decisions: similar=Suspected leak; different=No leak signal; uncertain=Uncertain; unreviewed=Pending review.\n`;
  return {blob:await zipStore(files),filename:stem+'.zip',contentType:'application/zip'};
 }
 return {FIELDS,DBF,csv,dxf,dbf,shpFiles,zipStore,makeExport,selectRows};
});
