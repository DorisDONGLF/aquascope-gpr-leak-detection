/* LandsD road tiles with on-device SGY tracks and linked B-scan footprints. */
'use strict';
class CandidateLocationMap {
 constructor(root,options={}){
  this.root=root;this.options=options;this.candidate=null;this.job=null;this.data=null;this.dataJob=null;this.epoch=0;this.windowVersion=0;this.enabled=false;this.rows=[];this.active=null;this.window=null;this.expanded=false;
  root.innerHTML=`<div class="candidate-map-heading"><div><span class="eyebrow">HONG KONG ROAD MAP · SGY GEOMETRY</span><h4 class="track-map-title">Candidate / channel locations</h4></div><div class="candidate-map-actions"><button type="button" class="text-button" data-track-action="enable">Show HK road map</button><button type="button" class="text-button" data-track-action="overview">Survey overview</button><button type="button" class="text-button" data-track-action="detail">Channel detail</button><button type="button" class="text-button" data-track-action="expand">Expand map</button><a class="text-button track-google" target="_blank" rel="noopener noreferrer">Google Maps ↗</a></div></div><div class="track-map-canvas" role="region" aria-label="Hong Kong road map with SGY channel tracks"></div><div class="track-map-status" role="status">Show the road map to load tiles from Lands Department. SGY tracks and signals stay on this device.</div><div class="track-map-legend"><span><i class="primary-track"></i>Primary swath</span><span><i class="nearby-track"></i>Associated swaths</span><span><i class="other-track"></i>Other input tracks</span><span><i class="window-track"></i>Current 8 m B-scan</span><span>● Fixed candidate / blue alignment · ○ AI centers</span></div><div class="track-map-current"></div><details class="track-local-plan"><summary>Channel relationship · Recorded XY</summary><div class="track-local-svg"></div><div class="track-channel-buttons" aria-label="Primary swath map channels"></div></details><p class="track-map-note">Positions use recorded SGY source XY (EPSG:2326). Antenna lever arms and absolute positioning have not been independently verified. Coincident coordinates are drawn at the same location.</p>`;
  this.canvas=root.querySelector('.track-map-canvas');this.status=root.querySelector('.track-map-status');this.current=root.querySelector('.track-map-current');this.local=root.querySelector('.track-local-svg');this.map=null;
  root.querySelector('[data-track-action=enable]').onclick=()=>this.enable();root.querySelector('[data-track-action=overview]').onclick=()=>this.fit(true);root.querySelector('[data-track-action=detail]').onclick=()=>this.fit(false,true);root.querySelector('[data-track-action=expand]').onclick=()=>this.expand();
  root.querySelector('.track-local-plan').ontoggle=()=>this.drawLocal();
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&this.expanded)this.expand()});
 }
 ll(xy){try{const p=GprGeo.toWgs84(xy[0],xy[1]);return [p.latitude,p.longitude]}catch{return null}}
 setCandidate(candidate,job){
  const changed=this.job?.id!==job?.id||this.candidate?.candidate_id!==candidate?.candidate_id;this.job=job;this.candidate=candidate;this.root.hidden=!candidate;
  if(!candidate){this.epoch++;this.windowVersion++;this.rows=[];this.active=null;this.window=null;this.clear();return}if(!changed){if(this.enabled&&this.dataJob===job?.id)this.draw();return}
  this.epoch++;this.windowVersion++;this.rows=[];this.active=null;this.window=null;this.root.querySelector('.track-map-title').textContent=`${candidate.candidate_id} · Primary swath ${candidate.profile}`;
  const p=this.ll([candidate.x,candidate.y]),google=this.root.querySelector('.track-google');google.hidden=!p;if(p)google.href=GprGeo.googleMapsUrl({latitude:p[0],longitude:p[1]});
  if(!p){this.status.textContent='Reliable Hong Kong Grid coordinates are unavailable for this candidate.';this.clear();return}
  if(this.enabled)this.load();
 }
 setGallery(gallery){
  const rows=[...(gallery.main_rows||[]).flatMap(r=>r.aligned_alternatives||[r]),...(gallery.groups||[]).flatMap(g=>g.rows)];
  this.rows=[...new Map(rows.filter(r=>r.view_kind==='merged').map(r=>[r.observation_id,r])).values()];if(this.enabled&&this.dataJob===this.job?.id)this.draw();
 }
 setObservation(row,scope){
  this.active={row,scope};this.windowVersion++;this.window=null;this.current.textContent=`Viewing ${scope==='primary'?'primary':'nearby'} swath · CH${row.channel??'—'} · ${row.name} · AI trace ${row.trace_1based}`;
  if(this.enabled&&this.dataJob===this.job?.id){this.draw();this.loadWindow()}
 }
 enable(){
  if(!this.candidate||!this.ll([this.candidate.x,this.candidate.y]))return;
  if(!window.L){this.status.textContent='Map library unavailable. Reload this page.';return}
  this.enabled=true;this.root.querySelector('[data-track-action=enable]').hidden=true;
  if(!this.map){
   this.map=L.map(this.canvas,{preferCanvas:true,minZoom:10,maxZoom:24,scrollWheelZoom:false});
   this.tiles=L.tileLayer('https://mapapi.geodata.gov.hk/gs/api/v1.0.0/xyz/basemap/WGS84/{z}/{x}/{y}.png',{minZoom:10,maxNativeZoom:20,maxZoom:24,updateWhenIdle:true,keepBuffer:1,attribution:'Map from <a href="https://www.landsd.gov.hk/" target="_blank" rel="noopener">Lands Department</a> · <a href="https://portal.csdi.gov.hk/" target="_blank" rel="noopener">CSDI</a>'}).addTo(this.map);
   this.labels=L.tileLayer('https://mapapi.geodata.gov.hk/gs/api/v1.0.0/xyz/label/hk/en/WGS84/{z}/{x}/{y}.png',{minZoom:10,maxNativeZoom:20,maxZoom:24,updateWhenIdle:true,keepBuffer:1}).addTo(this.map);
   const logo=L.control({position:'bottomleft'});logo.onAdd=()=>{const a=L.DomUtil.create('a','landsd-map-logo');a.href='https://www.landsd.gov.hk/';a.target='_blank';a.rel='noopener';const img=document.createElement('img');img.alt='Lands Department';img.src=window.GPR_BROWSER_BUNDLE?.landsdLogo||new URL('./vendor/landsd_logo.svg',location.href).href;a.append(img);return a};logo.addTo(this.map);L.control.scale({imperial:false}).addTo(this.map);
   this.trackLayer=L.layerGroup().addTo(this.map);this.pointLayer=L.layerGroup().addTo(this.map);this.windowLayer=L.layerGroup().addTo(this.map);
   this.tiles.on('tileerror',()=>{this.status.textContent='Some LandsD tiles could not load. The recorded SGY geometry remains available; retry the map later.'});
   this.map.on('zoomend',()=>{if(this.map.getZoom()>20)this.status.textContent='Channel detail: road tiles are enlarged beyond native zoom 20. Vector positions still use recorded XY.'});
  }
  this.map.invalidateSize();this.load();
 }
 clear(){this.trackLayer?.clearLayers();this.pointLayer?.clearLayers();this.windowLayer?.clearLayers();this.local.replaceChildren()}
 async load(){
  const epoch=this.epoch,jobId=this.job.id;this.map.setView(this.ll([this.candidate.x,this.candidate.y]),20);this.status.textContent='Loading recorded channel geometry…';
  try{
   const data=this.dataJob===jobId?this.data:await GprLocal.spatialData(jobId,(_,text)=>{if(this.epoch===epoch)this.status.textContent=text});
   if(this.epoch!==epoch)return;this.data=data;this.dataJob=jobId;this.draw();this.fit(false);this.loadWindow();
   const missing=data.tracks.filter(t=>!t.paths?.length).length;this.status.textContent=`${data.tracks.length-missing} / ${data.tracks.length} recorded channel tracks loaded${missing?' · '+missing+' unavailable':''}. Click a merged hit or track to select its B-scan.`;
  }catch(e){if(this.epoch===epoch)this.status.textContent=e.message}
 }
 nearest(paths,target){
  let best=null;
  for(const path of paths||[])for(let i=1;i<path.length;i++){const a=path[i-1],b=path[i],dx=b[0]-a[0],dy=b[1]-a[1],d=dx*dx+dy*dy;if(!d)continue;const t=Math.max(0,Math.min(1,((target[0]-a[0])*dx+(target[1]-a[1])*dy)/d)),p=[a[0]+t*dx,a[1]+t*dy],distance=Math.hypot(p[0]-target[0],p[1]-target[1]);if(!best||distance<best.distance)best={point:p,distance,tangent:[dx/Math.sqrt(d),dy/Math.sqrt(d)]}}
  return best;
 }
 pickFile(track){const row=this.rows.filter(r=>r.file_id===track.file_id).sort((a,b)=>Number(b.primary)-Number(a.primary)||b.logit-a.logit)[0];if(row)this.options.onObservation?.(row);else this.status.textContent=`${track.name}: recorded track only; this channel has no merged B-scan for the selected candidate.`}
 draw(){
  if(!this.enabled||this.dataJob!==this.job?.id||!this.candidate)return;
  this.clear();const candidate=this.candidate,profiles=new Set((candidate._members||candidate.observation_gallery||[]).map(m=>m.profile)),main=candidate.profile;
  for(const track of this.data.tracks){
   const active=this.active?.row.file_id===track.file_id,color=track.profile===main?'#278bdd':profiles.has(track.profile)?'#f1a34a':'#a4aab0',weight=active?4:track.profile===main?2.5:profiles.has(track.profile)?2:1;
   const lines=track.paths.map(path=>path.map(p=>this.ll(p)).filter(Boolean)).filter(p=>p.length>1);if(!lines.length)continue;
   const line=L.polyline(lines,{color,weight,opacity:active?1:track.profile===main?.85:.5}).addTo(this.trackLayer);line.bindTooltip(`${track.profile} · CH${track.channel??'?'} · ${track.name}`);line.on('click',()=>this.pickFile(track));
  }
  for(const item of this.job.map_candidates||this.job.candidates){const point=this.ll([item.x,item.y]);if(!point)continue;const chosen=item.candidate_id===candidate.candidate_id;const marker=L.circleMarker(point,{radius:chosen?7:3.5,color:chosen?'#ff5f75':'#793b52',weight:chosen?3:1,fillColor:chosen?'#ff5f75':'#b76d81',fillOpacity:chosen?1:.6}).addTo(this.pointLayer);marker.bindTooltip(`${item.candidate_id} · CH${item.channel??'?'} · trace ${item.trace_1based}`);marker.on('click',()=>{if(!chosen)this.options.onCandidate?.(item.candidate_id)})}
  for(const row of this.rows){const point=this.ll([row.x,row.y]);if(!point)continue;const selected=this.active?.row.observation_id===row.observation_id,color=row.profile===main?'#12814f':'#d07717';const marker=L.circleMarker(point,{radius:selected?6:4,color,weight:2,fillOpacity:.15}).addTo(this.pointLayer);marker.bindTooltip(`${row.profile} · CH${row.channel} · AI trace ${row.trace_1based}`);marker.on('click',()=>this.options.onObservation?.(row))}
  this.drawWindow();this.drawLocal();
 }
 async loadWindow(){
  if(!this.active||!this.enabled||this.dataJob!==this.job.id)return;
  const version=++this.windowVersion,epoch=this.epoch,row=this.active.row;
  try{const result=await GprLocal.spatialWindow(this.job.id,row,this.candidate);if(version!==this.windowVersion||epoch!==this.epoch)return;this.window=result;this.drawWindow();this.drawLocal()}catch(e){if(epoch===this.epoch)this.status.textContent=e.message}
 }
 drawWindow(){
  this.windowLayer?.clearLayers();const w=this.window;if(!w?.available)return;
  const points=w.path.map(p=>this.ll(p)).filter(Boolean);L.polyline(points,{color:'#04bc8b',weight:8,opacity:.95}).addTo(this.windowLayer).bindTooltip(`Current B-scan · CH${w.channel} · 8 m context`);
  const marker=(xy,text,color)=>{const p=this.ll(xy);if(!p)return;return L.circleMarker(p,{radius:5,color,weight:2,fillColor:'#fff',fillOpacity:1}).addTo(this.windowLayer).bindTooltip(text,{permanent:false})};
  marker(w.left,`B-scan valid edge ${w.left_offset_m.toFixed(2)} m`,'#047b65');marker(w.right,`B-scan valid edge +${w.right_offset_m.toFixed(2)} m`,'#047b65');marker(w.center,'Fixed candidate projected onto this channel','#237bd0');if(w.ai)marker(w.ai,'AI center on this channel','#10a168');
 }
 fit(all=false,detail=false){
  if(!this.map||!this.candidate)return;let points=[];
  if(all&&this.data)points=this.data.tracks.flatMap(t=>t.paths.flat());
  else {points=[[this.candidate.x,this.candidate.y],...this.rows.map(r=>[r.x,r.y])];if(detail&&this.window?.available)points.push(this.window.left,this.window.right)}
  const valid=points.map(p=>this.ll(p)).filter(Boolean);if(!valid.length)return;
  if(valid.length===1||L.latLngBounds(valid).getNorthEast().equals(L.latLngBounds(valid).getSouthWest()))this.map.setView(valid[0],detail?22:20);else this.map.fitBounds(valid,{padding:[25,25],maxZoom:all?19:detail?22:20});
 }
 drawLocal(){
  if(!this.candidate||!this.data||this.dataJob!==this.job?.id)return;
  const target=[this.candidate.x,this.candidate.y],tracks=this.data.tracks.filter(t=>t.profile===this.candidate.profile&&t.paths.length),primary=tracks.find(t=>t.file_id===this.candidate.file_id),projection=this.nearest(primary?.paths||[],target);if(!projection)return;
  const f=projection.tangent,normal=[f[1],-f[0]],local=p=>{const dx=p[0]-target[0],dy=p[1]-target[1];return [dx*normal[0]+dy*normal[1],dx*f[0]+dy*f[1]]};
  const points=tracks.map(t=>{const near=this.nearest(t.paths,target),row=this.rows.find(r=>r.file_id===t.file_id&&r.alignment_version===4);return {track:t,p:row?{point:[row.alignment_x,row.alignment_y],distance:row.alignment_distance_m}:near,exact:!!row}}).filter(v=>v.p),span=Math.max(.35,...points.map(v=>Math.abs(local(v.p.point)[0])*1.3)),X=p=>300+local(p)[0]/span*260,Y=p=>115-local(p)[1]/4.5*90;
  const ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg');svg.setAttribute('viewBox','0 0 600 265');svg.setAttribute('aria-label','Primary swath channel relationship in recorded coordinates');
  const append=(tag,attrs,text)=>{const node=document.createElementNS(ns,tag);for(const [k,v]of Object.entries(attrs))node.setAttribute(k,v);if(text!==undefined)node.textContent=text;svg.append(node);return node};
  const clip=document.createElementNS(ns,'clipPath'),rect=document.createElementNS(ns,'rect');clip.id='trackLocalClip';rect.setAttribute('x','35');rect.setAttribute('y','24');rect.setAttribute('width','530');rect.setAttribute('height','192');clip.append(rect);svg.append(clip);
  append('rect',{x:0,y:0,width:600,height:265,fill:'#181b20'});append('line',{x1:40,y1:115,x2:560,y2:115,stroke:'#67717c','stroke-dasharray':'4 4'});append('text',{x:12,y:17,fill:'#b9c4cf','font-size':11},'Along primary record ↑ · Across-track positions in metres');append('text',{x:8,y:40,fill:'#b9c4cf','font-size':10},'+4 m');append('text',{x:8,y:205,fill:'#b9c4cf','font-size':10},'−4 m');
  const signatures=new Set();let coincident=0;
  for(const {track,p}of points){
   const signature=JSON.stringify(track.paths);if(signatures.has(signature))coincident++;signatures.add(signature);
   const selected=track.file_id===this.active?.row.file_id,paths=selected&&this.window?.available?[this.window.path]:track.paths,path=paths.map(line=>line.map((q,i)=>(i?'L':'M')+X(q).toFixed(2)+','+Y(q).toFixed(2)).join(' ')).join(' ');append('path',{d:path,fill:'none',stroke:selected?'#64e4bd':'#4d9cde','stroke-width':selected?3:1.3,'clip-path':'url(#trackLocalClip)'});
   const x=X(p.point),y=Y(p.point),dot=append('circle',{cx:x,cy:y,r:selected?5:3.5,fill:selected?'#64e4bd':'#4d9cde'});const title=document.createElementNS(ns,'title');title.textContent=`CH${track.channel} · ${p.distance.toFixed(3)} m from fixed candidate`;dot.append(title);dot.style.cursor='pointer';dot.onclick=()=>this.pickFile(track);
   if(!coincident||selected)append('text',{x,y:232,fill:selected?'#64e4bd':'#c8d6e5','font-size':11,'text-anchor':'middle','data-channel-label':'true'},'CH'+track.channel);
  }
  if(coincident){svg.querySelectorAll('[data-channel-label]').forEach(n=>n.remove());append('text',{x:300,y:232,fill:'#e6b66f','font-size':11,'text-anchor':'middle'},'Some channels share recorded XY; use the channel buttons below.')}
  this.root.querySelector('.track-map-note').textContent='Positions use recorded SGY source XY (EPSG:2326). Antenna lever arms and absolute positioning have not been independently verified.'+(coincident?' Some channels have identical recorded tracks; individual antenna offsets cannot be resolved.':'');
  append('circle',{cx:300,cy:115,r:5,fill:'#ff5f75'});append('text',{x:300,y:253,fill:'#b9c4cf','font-size':10,'text-anchor':'middle'},`Across-track span: ±${span.toFixed(2)} m · Red: fixed candidate${coincident?' · Coincident tracks: '+coincident+' (no offsets invented)':''}`);this.local.replaceChildren(svg);
  const buttons=this.root.querySelector('.track-channel-buttons');buttons.replaceChildren();for(const {track,p,exact}of points.sort((a,b)=>(a.track.channel??Infinity)-(b.track.channel??Infinity))){const button=document.createElement('button');button.type='button';button.className='text-button';button.textContent=`CH${track.channel??'?'} · ${exact?'':'≈'}${p.distance.toFixed(2)} m`;button.onclick=()=>this.pickFile(track);buttons.append(button)}
 }
 expand(){this.expanded=!this.expanded;this.root.classList.toggle('track-map-expanded',this.expanded);this.root.querySelector('[data-track-action=expand]').textContent=this.expanded?'Close expanded map':'Expand map';setTimeout(()=>this.map?.invalidateSize(),0)}
}
