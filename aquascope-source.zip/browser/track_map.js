/* LandsD road tiles with on-device SGY tracks and linked B-scan footprints. */
'use strict';
class CandidateLocationMap {
 constructor(root,options={}){
  this.root=root;this.options=options;this.candidate=null;this.job=null;this.data=null;this.dataJob=null;this.epoch=0;this.windowVersion=0;this.enabled=false;this.rows=[];this.active=null;this.window=null;this.expanded=false;this.plans=new Map();this.footprints=new Map();this.primaryRow=null;
  root.innerHTML=`<div class="candidate-map-heading"><div><span class="eyebrow">HONG KONG ROAD MAP · SGY GEOMETRY</span><h4 class="track-map-title">Candidate / channel locations</h4></div><div class="candidate-map-actions"><button type="button" class="text-button" data-track-action="enable">Show HK road map</button><button type="button" class="text-button" data-track-action="overview">Survey overview</button><button type="button" class="text-button" data-track-action="detail">Channel detail</button><button type="button" class="text-button" data-track-action="expand">Expand map</button><a class="text-button track-google" target="_blank" rel="noopener noreferrer">Google Maps ↗</a></div></div><div class="track-map-canvas" role="region" aria-label="Hong Kong road map with SGY channel tracks"></div><div class="track-map-status" role="status">Show the road map to load tiles from Lands Department. SGY tracks and signals stay on this device.</div><div class="track-map-legend"><span><i class="primary-track"></i>Primary swath</span><span><i class="nearby-track"></i>Associated swaths</span><span><i class="other-track"></i>Other input tracks</span><span><i class="window-track"></i>Current 8 m B-scan</span><span>● Candidate center · ━ Window edges · ○ Channel AI centers</span></div><div class="track-map-current"></div><details class="track-local-plan"><summary>Primary swath · Channel relationship</summary><div class="track-local-svg"></div><div class="track-channel-buttons" aria-label="Primary swath map channels"></div></details><p class="track-map-note">Positions use recorded SGY source XY (EPSG:2326). Antenna lever arms and absolute positioning have not been independently verified. Coincident coordinates are drawn at the same location.</p>`;
  this.canvas=root.querySelector('.track-map-canvas');this.status=root.querySelector('.track-map-status');this.current=root.querySelector('.track-map-current');this.local=root.querySelector('.track-local-svg');this.map=null;
  root.querySelector('[data-track-action=enable]').onclick=()=>this.enable();root.querySelector('[data-track-action=overview]').onclick=()=>this.fit(true);root.querySelector('[data-track-action=detail]').onclick=()=>this.fit(false,true);root.querySelector('[data-track-action=expand]').onclick=()=>this.expand();
  root.querySelector('.track-local-plan').ontoggle=()=>this.drawLocal();
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&this.expanded)this.expand()});
 }
 ll(xy){try{const p=GprGeo.toWgs84(xy[0],xy[1]);return [p.latitude,p.longitude]}catch{return null}}
 setCandidate(candidate,job){
  const changed=this.job?.id!==job?.id||this.candidate?.candidate_id!==candidate?.candidate_id;this.job=job;this.candidate=candidate;this.root.hidden=!candidate;
  if(!candidate){this.epoch++;this.windowVersion++;this.rows=[];this.active=null;this.window=null;this.primaryRow=null;this.plans.clear();this.footprints.clear();this.clear();return}if(!changed){if(this.enabled&&this.dataJob===job?.id)this.draw();return}
  this.epoch++;this.windowVersion++;this.rows=[];this.active=null;this.window=null;this.primaryRow=null;this.plans.clear();this.footprints.clear();this.root.querySelector('.track-map-title').textContent=`${candidate.candidate_id} · Primary swath ${candidate.profile}`;
  const p=this.ll([candidate.x,candidate.y]),google=this.root.querySelector('.track-google');google.hidden=!p;if(p)google.href=GprGeo.googleMapsUrl({latitude:p[0],longitude:p[1]});
  if(!p){this.status.textContent='Reliable Hong Kong Grid coordinates are unavailable for this candidate.';this.clear();return}
  if(this.enabled)this.load();
 }
 setGallery(gallery){
  const rows=[...(gallery.main_rows||[]).flatMap(r=>r.aligned_alternatives||[r]),...(gallery.groups||[]).flatMap(g=>g.rows)];
  this.rows=[...new Map(rows.filter(r=>r.view_kind==='merged').map(r=>[r.observation_id,r])).values()];this.ensureGeometry().catch(()=>{});if(this.enabled&&this.dataJob===this.job?.id)this.draw();
 }
 setObservation(row,scope){
  if(scope==='primary')this.primaryRow=row;this.active={row,scope};this.windowVersion++;this.window=null;this.current.textContent=`Viewing ${scope==='primary'?'primary':'nearby'} swath · CH${row.channel??'—'} · ${row.name} · AI trace ${row.trace_1based}`;
  if(this.enabled&&this.dataJob===this.job?.id){this.draw();this.loadWindow()}else{this.drawLocal();this.footprint(row).then(()=>this.drawLocal()).catch(()=>{})}
 }
 enable(){
  if(!this.candidate||!this.ll([this.candidate.x,this.candidate.y]))return;
  if(!window.L){this.status.textContent='Map library unavailable. Reload this page.';return}
  this.enabled=true;this.root.querySelector('[data-track-action=enable]').hidden=true;
  if(!this.map){
   this.map=L.map(this.canvas,{preferCanvas:true,minZoom:10,maxZoom:24,scrollWheelZoom:false});
   this.tiles=L.tileLayer('https://mapapi.geodata.gov.hk/gs/api/v1.0.0/xyz/basemap/WGS84/{z}/{x}/{y}.png',{minZoom:10,maxNativeZoom:20,maxZoom:24,updateWhenIdle:true,keepBuffer:1,attribution:'Map from <a href="https://www.landsd.gov.hk/" target="_blank" rel="noopener">Lands Department</a> · <a href="https://portal.csdi.gov.hk/" target="_blank" rel="noopener">CSDI</a>'}).addTo(this.map);
   this.labels=L.tileLayer('https://mapapi.geodata.gov.hk/gs/api/v1.0.0/xyz/label/hk/en/WGS84/{z}/{x}/{y}.png',{minZoom:10,maxNativeZoom:20,maxZoom:24,updateWhenIdle:true,keepBuffer:1}).addTo(this.map);
   const logo=L.control({position:'bottomleft'});logo.onAdd=()=>{const a=L.DomUtil.create('a','landsd-map-logo');a.href='https://www.landsd.gov.hk/';a.target='_blank';a.rel='noopener';const img=document.createElement('img');img.alt='Lands Department';img.src=window.GPR_BROWSER_BUNDLE?.landsdLogo||new URL('./vendor/landsd_logo.svg',location.href).href;a.append(img);return a};logo.addTo(this.map);L.control.scale({imperial:false}).addTo(this.map);
   this.trackLayer=L.layerGroup().addTo(this.map);this.pointLayer=L.layerGroup().addTo(this.map);this.windowLayer=L.layerGroup().addTo(this.map);
   this.tiles.on('tileerror',()=>{this.status.textContent='Some LandsD tiles could not load. The recorded SGY geometry remains available; retry the map later.'});
   this.map.on('zoomend',()=>{if(this.map.getZoom()>20)this.status.textContent='Channel detail: road tiles are enlarged beyond native zoom 20. Vector positions still use recorded XY.'});
  }
  this.map.invalidateSize();this.load();
 }
 clear(){this.trackLayer?.clearLayers();this.pointLayer?.clearLayers();this.windowLayer?.clearLayers();this.local.replaceChildren()}
 async load(){
  const epoch=this.epoch,jobId=this.job.id;this.map.setView(this.ll([this.candidate.x,this.candidate.y]),20);this.status.textContent='Loading recorded channel geometry…';
  try{
   const data=await this.ensureGeometry();
   if(this.epoch!==epoch)return;this.data=data;this.dataJob=jobId;this.draw();this.fit(false);this.loadWindow();
   const missing=data.tracks.filter(t=>!t.paths?.length).length;this.status.textContent=`${data.tracks.length-missing} / ${data.tracks.length} recorded channel tracks loaded${missing?' · '+missing+' unavailable':''}. Click a merged hit or track to select its B-scan.`;
  }catch(e){if(this.epoch===epoch)this.status.textContent=e.message}
 }
 nearest(paths,target){
  let best=null;
  for(const path of paths||[])for(let i=1;i<path.length;i++){const a=path[i-1],b=path[i],dx=b[0]-a[0],dy=b[1]-a[1],d=dx*dx+dy*dy;if(!d)continue;const t=Math.max(0,Math.min(1,((target[0]-a[0])*dx+(target[1]-a[1])*dy)/d)),p=[a[0]+t*dx,a[1]+t*dy],distance=Math.hypot(p[0]-target[0],p[1]-target[1]);if(!best||distance<best.distance)best={point:p,distance,tangent:[dx/Math.sqrt(d),dy/Math.sqrt(d)]}}
  return best;
 }
 pickFile(track){const row=this.rows.filter(r=>r.file_id===track.file_id).sort((a,b)=>Number(b.primary)-Number(a.primary)||b.logit-a.logit)[0];if(row)this.options.onObservation?.(row);else this.status.textContent=`${track.name}: recorded track only; this channel has no merged B-scan for the selected candidate.`}
 draw(){
  if(!this.enabled||this.dataJob!==this.job?.id||!this.candidate)return;
  this.clear();const candidate=this.candidate,profiles=new Set((candidate._members||candidate.observation_gallery||[]).map(m=>m.profile)),main=candidate.profile;
  for(const track of this.data.tracks){
   const active=this.active?.row.file_id===track.file_id,color=track.profile===main?'#278bdd':profiles.has(track.profile)?'#f1a34a':'#a4aab0',weight=active?4:track.profile===main?2.5:profiles.has(track.profile)?2:1;
   const lines=track.paths.map(path=>path.map(p=>this.ll(p)).filter(Boolean)).filter(p=>p.length>1);if(!lines.length)continue;
   const line=L.polyline(lines,{color,weight,opacity:active?1:track.profile===main?.85:.5}).addTo(this.trackLayer);line.bindTooltip(`${track.profile} · CH${track.channel??'?'} · ${track.name}`);line.on('click',()=>this.pickFile(track));
  }
  for(const item of this.job.map_candidates||this.job.candidates){if(item.candidate_id===candidate.candidate_id)continue;const point=this.ll([item.x,item.y]);if(!point)continue;const chosen=item.candidate_id===candidate.candidate_id;const marker=L.circleMarker(point,{radius:chosen?7:3.5,color:chosen?'#ff5f75':'#793b52',weight:chosen?3:1,fillColor:chosen?'#ff5f75':'#b76d81',fillOpacity:chosen?1:.6}).addTo(this.pointLayer);marker.bindTooltip(`${item.candidate_id} · CH${item.channel??'?'} · trace ${item.trace_1based}`);marker.on('click',()=>{if(!chosen)this.options.onCandidate?.(item.candidate_id)})}
  for(const row of this.rows){const point=this.ll([row.x,row.y]);if(!point)continue;const selected=this.active?.row.observation_id===row.observation_id,color=row.profile===main?'#12814f':'#d07717';const marker=L.circleMarker(point,{radius:selected?6:4,color,weight:2,fillOpacity:.15}).addTo(this.pointLayer);marker.bindTooltip(`${row.profile} · CH${row.channel} · AI trace ${row.trace_1based}`);marker.on('click',()=>this.options.onObservation?.(row))}
  this.drawWindow();this.drawLocal();
 }
 async loadWindow(){
  if(!this.active||!this.enabled||this.dataJob!==this.job.id)return;
  const version=++this.windowVersion,epoch=this.epoch,row=this.active.row;
  try{const result=await this.footprint(row);if(version!==this.windowVersion||epoch!==this.epoch)return;this.window=result;this.drawWindow();this.drawLocal()}catch(e){if(epoch===this.epoch)this.status.textContent=e.message}
 }
 drawWindow(){
  this.windowLayer?.clearLayers();if(!this.windowLayer||!this.candidate)return;const w=this.window;
  if(w?.available){
   L.polyline(w.path.map(p=>this.ll(p)).filter(Boolean),{color:'#04bc8b',weight:8,opacity:.95}).addTo(this.windowLayer).bindTooltip(`Current B-scan · CH${w.channel} · 8 m context`);
   for(const [xy,offset]of [[w.left,w.left_offset_m],[w.right,w.right_offset_m]]){const p=this.ll(xy);if(p)L.marker(p,{icon:L.divIcon({className:'bscan-edge-tick',html:'<span></span>',iconSize:[18,5],iconAnchor:[9,2.5]})}).addTo(this.windowLayer).bindTooltip(`B-scan valid edge ${offset.toFixed(2)} m`)}
   const away=xy=>Math.hypot(xy[0]-this.candidate.x,xy[1]-this.candidate.y)>.02;
   if(away(w.center))L.marker(this.ll(w.center),{icon:L.divIcon({className:'candidate-projection-cross',html:'<span>+</span>',iconSize:[16,16],iconAnchor:[8,8]})}).addTo(this.windowLayer).bindTooltip('Candidate center projected onto this channel');
   if(w.ai&&away(w.ai))L.circleMarker(this.ll(w.ai),{radius:4,color:'#10a168',weight:2,fillOpacity:0}).addTo(this.windowLayer).bindTooltip('AI center on this channel');
  }
  const point=this.ll([this.candidate.x,this.candidate.y]);if(point)L.circleMarker(point,{radius:8,color:'#fff',weight:2,fillColor:'#ff5f75',fillOpacity:1}).addTo(this.windowLayer).bindTooltip('Candidate center',{permanent:true,direction:'top',offset:[0,-10],className:'candidate-center-label'});
 }
 fit(all=false,detail=false){
  if(!this.map||!this.candidate)return;let points=[];
  if(all&&this.data)points=this.data.tracks.flatMap(t=>t.paths.flat());
  else {points=[[this.candidate.x,this.candidate.y],...this.rows.map(r=>[r.x,r.y])];if(detail&&this.window?.available)points.push(this.window.left,this.window.right)}
  const valid=points.map(p=>this.ll(p)).filter(Boolean);if(!valid.length)return;
  if(valid.length===1||L.latLngBounds(valid).getNorthEast().equals(L.latLngBounds(valid).getSouthWest()))this.map.setView(valid[0],detail?22:20);else this.map.fitBounds(valid,{padding:[25,25],maxZoom:all?19:detail?22:20});
 }
 async ensureGeometry(){
  if(!this.candidate||!this.job)return null;const epoch=this.epoch,jobId=this.job.id;
  if(this.dataJob===jobId){this.drawLocal();return this.data}
  try{const data=await GprLocal.spatialData(jobId);if(this.epoch!==epoch)return null;this.data=data;this.dataJob=jobId;this.drawLocal();return data}catch(e){if(this.epoch===epoch){this.local.textContent=e.message;for(const [host]of this.plans)if(host.isConnected)host.querySelector('.channel-plan-drawing').textContent=e.message}throw e}
 }
 footprint(row){
  const key=row.observation_id;if(!this.footprints.has(key)){const epoch=this.epoch,jobId=this.job.id,candidate=this.candidate;const entry={value:null,promise:null};entry.promise=GprLocal.spatialWindow(jobId,row,candidate).then(value=>{if(this.epoch===epoch)entry.value=value;return value}).catch(e=>{if(this.epoch===epoch)this.footprints.delete(key);throw e});this.footprints.set(key,entry)}return this.footprints.get(key).promise;
 }
 setPlan(host,row){
  if(!host)return;let state=this.plans.get(host);
  if(!state){host.innerHTML='<details class="swath-plan-details" open><summary>Channel relationship · This swath vs primary</summary><p class="channel-plan-profile"></p><div class="channel-plan-drawing"></div><div class="track-channel-buttons"></div></details>';state={row};this.plans.set(host,state)}
  state.row=row;host.querySelector('.channel-plan-profile').textContent=`This swath: ${row.profile} · Primary: ${this.candidate.profile} · Viewing CH${row.channel}`;
  this.ensureGeometry().then(()=>this.renderPlan(host,state)).catch(()=>{});
  this.footprint(row).then(()=>{if(this.plans.get(host)===state&&state.row.observation_id===row.observation_id)this.renderPlan(host,state)}).catch(e=>{if(host.isConnected)host.querySelector('.channel-plan-drawing').textContent=e.message});
 }
 plan(profile,row){return GprChannelPlan.build(this.data,this.candidate,profile,this.rows,row,this.footprints.get(row?.observation_id)?.value)}
 renderPlan(host,state){
  if(!host.isConnected){this.plans.delete(host);return}if(!this.data||this.dataJob!==this.job?.id||!this.candidate)return;
  const plan=this.plan(state.row.profile,state.row);GprChannelPlan.render(host.querySelector('.channel-plan-drawing'),plan,{onFile:t=>this.pickFile(t)});this.planButtons(host.querySelector('.track-channel-buttons'),plan,state.row.profile);
 }
 planButtons(host,plan,profile){
  host.replaceChildren();if(!plan.available)return;for(const e of plan.entries.filter(v=>v.track.profile===profile).sort((a,b)=>(a.track.channel??Infinity)-(b.track.channel??Infinity))){const button=document.createElement('button');button.type='button';button.className='text-button';button.textContent=`CH${e.track.channel??'?'} · ${e.exact?'':'≈'}${e.distance.toFixed(2)} m`;button.setAttribute('aria-pressed',String(e.active));button.onclick=()=>this.pickFile(e.track);host.append(button)}
 }
 drawLocal(){
  if(!this.candidate||!this.data||this.dataJob!==this.job?.id)return;
  const plan=this.plan(this.candidate.profile,this.primaryRow);GprChannelPlan.render(this.local,plan,{onFile:t=>this.pickFile(t)});this.planButtons(this.root.querySelector('.track-channel-buttons'),plan,this.candidate.profile);
  this.root.querySelector('.track-map-note').textContent='Positions use recorded SGY source XY (EPSG:2326). Antenna lever arms and absolute positioning have not been independently verified.'+(plan.coincident?' Some channels share recorded XY; labels do not invent antenna offsets.':'');
  for(const [host,state]of this.plans)this.renderPlan(host,state);
 }
 expand(){this.expanded=!this.expanded;this.root.classList.toggle('track-map-expanded',this.expanded);this.root.querySelector('[data-track-action=expand]').textContent=this.expanded?'Close expanded map':'Expand map';setTimeout(()=>this.map?.invalidateSize(),0)}
}
