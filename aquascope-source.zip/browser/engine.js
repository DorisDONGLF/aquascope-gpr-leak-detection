/* Numerical SGY inference and coordinate alignment, shared by worker and tests. */
(function(root,factory){const value=factory();if(typeof module==='object'&&module.exports)module.exports=value;else root.GprEngine=value})(typeof self!=='undefined'?self:globalThis,function(){
 'use strict';
 const f32=Math.fround, clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
 function roundEven(x){const low=Math.floor(x),delta=x-low;return delta===.5?(low%2?low+1:low):Math.round(x)}
 function select(a,k){
  let left=0,right=a.length-1;
  while(left<right){
   const pivot=a[(left+right)>>>1];let low=left,i=left,high=right;
   while(i<=high){if(a[i]<pivot){const t=a[low];a[low++]=a[i];a[i++]=t}else if(a[i]>pivot){const t=a[high];a[high--]=a[i];a[i]=t}else i++}
   if(k<low)right=low-1;else if(k>high)left=high+1;else return a[k];
  }
  return a[k];
 }
 function quantileAbs(values,q=.99,torchRank=false){
  const a=Float32Array.from(values,v=>Math.abs(v));
  if(!a.length)return 1;
  const rank=torchRank?f32(f32(q)*(a.length-1)):q*(a.length-1),lo=Math.floor(rank),hi=Math.ceil(rank);
  const low=select(a,lo),high=hi===lo?low:select(a,hi),w=rank-lo;
  return torchRank?f32(low+f32(w*f32(high-low))):low+w*(high-low);
 }
 function median(values){if(!values.length)return NaN;const a=Float64Array.from(values);const k=Math.floor(a.length/2),b=select(a,k);return a.length%2?b:(select(a,k-1)+b)/2}
 function parseSgy(buffer,fallback=.04){
  const v=ArrayBuffer.isView(buffer)?new DataView(buffer.buffer,buffer.byteOffset,buffer.byteLength):new DataView(buffer);
  if(v.byteLength<3840)throw Error('File is too short to read the SEG-Y header.');
  const ns=v.getUint16(3220),format=v.getUint16(3224),ext=v.getInt16(3504);
  if(format!==2)throw Error(`SEG-Y format ${format} is unsupported. Use big-endian int32 format 2.`);
  if(ns<1||ns>20000)throw Error('Invalid vertical sample count.');
  if(ext<0||ext>100)throw Error('Unsupported extended text-header layout.');
  const offset=3600+ext*3200,stride=240+ns*4,n=(v.byteLength-offset)/stride;
  if(!Number.isInteger(n)||n<2)throw Error('Unsupported variable-length traces or SEG-Y record layout.');
  const samples=new Float32Array(n*ns),x=new Float64Array(n),y=new Float64Array(n),units=new Set(),valid=[];
  let coordinateAvailable=false;
  for(let i=0;i<n;i++){
   const p=offset+i*stride,traceNs=v.getUint16(p+114);
   if(traceNs!==0&&traceNs!==ns)throw Error('Inconsistent trace-header sample counts.');
   const scalar=v.getInt16(p+70),scale=scalar>0?scalar:1/Math.max(Math.abs(scalar),1);
   x[i]=v.getInt32(p+72)*scale;y[i]=v.getInt32(p+76)*scale;units.add(v.getUint16(p+88));
   coordinateAvailable||=x[i]!==0||y[i]!==0;
   if(i){const d=Math.hypot(x[i]-x[i-1],y[i]-y[i-1]);if(d>.001&&d<10)valid.push(d)}
   for(let j=0;j<ns;j++)samples[i*ns+j]=v.getInt32(p+240+4*j);
  }
  const measurement=v.getUint16(3254);
  coordinateAvailable&&=[...units].every(u=>u<=1)&&measurement!==2&&valid.length>0;
  const spacing=coordinateAvailable?median(valid):Number(fallback);
  if(!Number.isFinite(spacing)||spacing<=0)throw Error('Cannot determine trace spacing. Supply a positive fallback in meters per trace.');
  return {samples,x,y,n,ns,recordOffset:offset,traceStride:stride,spacing,coordinateAvailable,meta:{traces:n,samples_per_trace:ns,format_code:format,byte_order:'big endian',sample_interval_raw:v.getUint16(3216),sample_interval_units_verified:false,vertical_extent:'Full SGY record; all vertical samples retained',coordinate_available:coordinateAvailable,coordinate_units_raw:[...units].sort(),spacing_m:spacing,spacing_source:coordinateAvailable?'Median spacing from source XY':'User-supplied fallback spacing',measurement_system_raw:measurement}};
 }
 function metallicMask(sgy,threshold=3){
  threshold=Number(threshold);if(!Number.isFinite(threshold)||threshold<1||threshold>10)throw Error('Metallic mute threshold must be between 1 and 10.');
  const amplitudes=new Float64Array(sgy.n),positive=[];
  for(let i=0;i<sgy.n;i++){let sum=0;for(let r=0;r<sgy.ns;r++)sum+=Math.abs(sgy.samples[i*sgy.ns+r]);const value=sum/sgy.ns;amplitudes[i]=value;if(value>0)positive.push(value)}
  // Ignore existing zero traces when estimating the background amplitude.
  const baseline=positive.length?median(positive):0,cutoff=baseline*threshold,mask=new Uint8Array(sgy.n),ranges=[];
  let count=0,start=-1;
  for(let i=0;i<=sgy.n;i++){
   const flagged=i<sgy.n&&baseline>0&&amplitudes[i]>cutoff;
   if(flagged){mask[i]=1;count++;if(start<0)start=i}
   else if(start>=0){ranges.push([start+1,i]);start=-1}
  }
  const report={method:'mean_absolute_trace_amplitude_v1',mode:'mute',threshold,baseline:'median of nonzero trace mean-absolute amplitudes',baseline_amplitude:baseline,cutoff_amplitude:cutoff,total_traces:sgy.n,muted_traces:count,muted_percent:count/sgy.n*100,ranges_1based_inclusive:ranges,manhole_classification:false};
  return {mask,amplitudes,report};
 }
 function applyMetalMute(sgy,options={},copy=true){
  if(!options.metal_mute)return sgy;
  const mode=options.metal_mode||'selected_ranges';
  if(!['auto_amplitude','selected_ranges'].includes(mode))throw Error('Unsupported metallic mute mode.');
  const plan=mode==='auto_amplitude'?metallicMask(sgy,options.metal_threshold??5):selectedMetalMask(sgy.n,options.metal_ranges||[]),samples=copy?sgy.samples.slice():sgy.samples;
  for(let i=0;i<sgy.n;i++)if(plan.mask[i])samples.fill(0,i*sgy.ns,(i+1)*sgy.ns);
  return {...sgy,samples,mutedMask:plan.mask,meta:{...sgy.meta,metal_mute:{...plan.report,selection_mode:mode}}};
 }
 function selectedMetalMask(n,ranges){
  if(!Array.isArray(ranges))throw Error('Choose valid trace ranges to mute.');
  const mask=new Uint8Array(n);
  for(const range of ranges){if(!Array.isArray(range)||range.length!==2||!range.every(Number.isInteger)||range[0]<1||range[1]>n||range[1]<range[0])throw Error('Mute ranges must be whole trace numbers within the SGY file.');mask.fill(1,range[0]-1,range[1])}
  const merged=[];let start=-1,count=0;
  for(let i=0;i<=n;i++){if(i<n&&mask[i]){count++;if(start<0)start=i}else if(start>=0){merged.push([start+1,i]);start=-1}}
  return {mask,report:{method:'user_selected_trace_ranges_v1',mode:'mute',total_traces:n,muted_traces:count,muted_percent:count/n*100,ranges_1based_inclusive:merged,manhole_classification:false}};
 }
 function fileKey(file){return file.name+'|'+file.size+'|'+(file.file?.lastModified??file.lastModified??0)}
 function fileMuteOptions(file,options={}){return {...options,metal_ranges:options.metal_ranges_by_file?.[fileKey(file)]||[]}}
 function mutedSgyBytes(buffer,sgy,mask){
  const source=ArrayBuffer.isView(buffer)?new Uint8Array(buffer.buffer,buffer.byteOffset,buffer.byteLength):new Uint8Array(buffer),bytes=source.slice();
  if(mask.length!==sgy.n||sgy.recordOffset+sgy.n*sgy.traceStride!==bytes.length)throw Error('Mute mask does not match the SGY record layout.');
  for(let i=0;i<sgy.n;i++)if(mask[i]){const start=sgy.recordOffset+i*sgy.traceStride+240;bytes.fill(0,start,start+sgy.ns*4)}
  return bytes;
 }
 function preprocess(sgy,center,half){
  const height=128,width=193,inputWidth=2*half+1,out=new Float32Array(height*width);
  const xx=[];
  for(let c=0;c<width;c++){
   const src=Math.max(0,f32(f32(f32(inputWidth/width)*f32(c+.5))-.5)),low=Math.floor(src),high=Math.min(low+1,inputWidth-1);
   xx.push([clamp(center-half+low,0,sgy.n-1),clamp(center-half+high,0,sgy.n-1),f32(src-low)]);
  }
  for(let r=0;r<height;r++){
   const src=Math.max(0,(r+.5)*sgy.ns/height-.5),low=Math.floor(src),high=Math.min(low+1,sgy.ns-1),wy=f32(src-low),iy=f32(1-wy);
   for(let c=0;c<width;c++){
    const [a,b,wx]=xx[c],ix=f32(1-wx);
    const top=f32(f32(sgy.samples[a*sgy.ns+low]*ix)+f32(sgy.samples[b*sgy.ns+low]*wx));
    const bottom=f32(f32(sgy.samples[a*sgy.ns+high]*ix)+f32(sgy.samples[b*sgy.ns+high]*wx));
    out[r*width+c]=f32(f32(top*iy)+f32(bottom*wy));
   }
  }
  const limit=Math.max(quantileAbs(out,.99,true),1e-12);
  for(let i=0;i<out.length;i++)out[i]=clamp(f32(out[i]/limit),-1,1);
  return out;
 }
 function groupPeaks(peaks,merge){
  const sites=[],buckets=new Map();
  for(const r of [...peaks].sort((a,b)=>b.logit-a.logit)){
   let matches=[],cell;
   if(r.x!==null){
    cell=[Math.floor(r.x/merge),Math.floor(r.y/merge)];
    for(const ax of [-1,0,1])for(const ay of [-1,0,1])for(const i of buckets.get((cell[0]+ax)+','+(cell[1]+ay))||[])
     if(Math.hypot(r.x-sites[i].x,r.y-sites[i].y)<merge)matches.push(i);
   }else matches=sites.map((s,i)=>s.file_id===r.file_id&&Math.abs(s.trace_1based-r.trace_1based)*r.spacing_m<merge?i:-1).filter(i=>i>=0);
   const distance=i=>r.x!==null?Math.hypot(r.x-sites[i].x,r.y-sites[i].y):Math.abs(r.trace_1based-sites[i].trace_1based);
   if(matches.length){let best=matches[0];for(const i of matches)if(distance(i)<distance(best))best=i;sites[best]._members.push({...r})}
   else {if(cell){const key=cell.join(',');if(!buckets.has(key))buckets.set(key,[]);buckets.get(key).push(sites.length)}sites.push({...r,_members:[{...r}]})}
  }
  sites.forEach((s,i)=>Object.assign(s,{candidate_id:'C'+String(i+1).padStart(4,'0'),supporting_observations:s._members.length,supporting_channels:[...new Set(s._members.filter(r=>r.profile===s.profile&&r.channel!==null).map(r=>r.channel))].sort((a,b)=>a-b),supporting_swaths:new Set(s._members.map(r=>r.profile)).size,review_label:'unreviewed',reviewer:'',notes:'',panels:[]}));
  return sites;
 }
 async function scanFiles(files,options,runtime,progress=()=>{},cancelled=()=>false){
  const started=Date.now(),peaks=[],metadata=[],scores=[],batchSize=options.batch_size||8;
  let total=0,hits=0;
  for(let fi=0;fi<files.length;fi++){
   if(cancelled())throw Error('Detection cancelled.');
   const file=files[fi];progress(.8*fi/files.length,`Reading ${file.name}`);
   const sgy=applyMetalMute(parseSgy(await file.file.arrayBuffer(),options.spacing_m),fileMuteOptions(file,options),false),half=Math.max(1,roundEven(4/sgy.spacing)),step=Math.max(1,roundEven(options.step_m/sgy.spacing));
   const centers=[];for(let j=half;j<sgy.n-half;j+=step)centers.push(j);
   const logs=new Float32Array(centers.length),match=/-(\d+)\.(?:sgy|segy)$/i.exec(file.name),channel=match?Number(match[1]):null,profile=match?file.name.slice(0,match.index):file.name.replace(/\.[^.]+$/,'');
   const meta={...sgy.meta,name:file.name,file_id:file.id,channel,profile,step_m:step*sgy.spacing,edge_unscanned_est_m:half*sgy.spacing,excluded_known_windows:0};
   let skipped=0,skippedMuted=0;
   for(let off=0;off<centers.length;off+=batchSize){
    if(cancelled())throw Error('Detection cancelled.');
    const indices=centers.slice(off,off+batchSize),valid=[],arrays=[];
    indices.forEach((j,i)=>{if(sgy.mutedMask?.[j]){logs[off+i]=-Infinity;skipped++;skippedMuted++;return}const a=preprocess(sgy,j,half);if(a.some(v=>v!==0)){valid.push(i);arrays.push(a)}else {logs[off+i]=-Infinity;skipped++}});
    if(arrays.length){const values=new Float32Array(arrays.length*128*193);arrays.forEach((a,i)=>values.set(a,i*128*193));const result=await runtime.presence(values,arrays.length);valid.forEach((index,i)=>logs[off+index]=result[i])}
    progress(.8*(fi+Math.min(off+indices.length,centers.length)/Math.max(1,centers.length))/files.length,`Scanning ${file.name} · ${Math.min(off+indices.length,centers.length)} / ${centers.length} windows`);
   }
   const threshold=Math.log(options.threshold/(1-options.threshold));
   const above=centers.map((_,i)=>i).filter(i=>Number.isFinite(logs[i])&&logs[i]>=threshold).sort((a,b)=>logs[b]-logs[a]||a-b),chosen=[];
   for(const ix of above)if(chosen.every(j=>Math.abs(centers[ix]-centers[j])*sgy.spacing>=options.merge_m&&(!sgy.coordinateAvailable||Math.hypot(sgy.x[centers[ix]]-sgy.x[centers[j]],sgy.y[centers[ix]]-sgy.y[centers[j]])>=options.merge_m)))chosen.push(ix);
   for(let off=0;off<chosen.length;off+=batchSize){
    if(cancelled())throw Error('Detection cancelled.');
    const inds=chosen.slice(off,off+batchSize),values=new Float32Array(inds.length*128*193);
    inds.forEach((ix,k)=>values.set(preprocess(sgy,centers[ix],half),k*128*193));
    const positions=await runtime.localizer(values,inds.length);
    inds.forEach((ix,k)=>{
     let col=0;for(let c=1;c<193;c++)if(positions[k*193+c]>positions[k*193+col])col=c;
     const j=centers[ix],est=clamp(j-half+roundEven((col+.5)*(2*half+1)/193-.5),0,sgy.n-1);
     if(sgy.mutedMask?.[est])return;
     peaks.push({file_id:file.id,name:file.name,profile,channel,trace_1based:est+1,window_center_trace_1based:j+1,x:sgy.coordinateAvailable?sgy.x[est]:null,y:sgy.coordinateAvailable?sgy.y[est]:null,window_center_x:sgy.coordinateAvailable?sgy.x[j]:null,window_center_y:sgy.coordinateAvailable?sgy.y[j]:null,distance_to_known_m:null,near_known:false,logit:logs[ix],signal_score:1/(1+Math.exp(-Math.min(logs[ix],80))),spacing_m:sgy.spacing,localizer_shift_m:(est-j)*sgy.spacing,samples_per_trace:sgy.ns});
    });
   }
   meta.scored_windows=centers.length-skipped;meta.skipped_muted_center_windows=skippedMuted;meta.skipped_zero_windows=skipped-skippedMuted;meta.threshold_hits=above.length;metadata.push(meta);
   scores.push({file_id:file.id,trace_1based:centers.map(c=>c+1),logit:Array.from(logs,l=>Number.isFinite(l)?l:null)});total+=meta.scored_windows;hits+=above.length;
  }
  progress(.82,'Merging repeated windows and channel observations');
  const candidates=groupPeaks(peaks,options.merge_m);
  return {candidates,files:metadata,scores,summary:{candidate_count:candidates.length,scored_windows:total,threshold_hit_windows:hits,channel_peaks:peaks.length,sgy_count:files.length,swath_count:new Set(metadata.map(m=>m.profile)).size,elapsed_seconds:Math.round((Date.now()-started)/100)/10,threshold:options.threshold,step_m:options.step_m,merge_m:options.merge_m,metal_mute_enabled:!!options.metal_mute,metal_mute_mode:options.metal_mute?(options.metal_mode||'selected_ranges'):'raw',metal_mute_threshold:options.metal_mute&&options.metal_mode==='auto_amplitude'?(options.metal_threshold??5):null,metal_processed_files:metadata.filter(m=>m.metal_mute).length,muted_traces:metadata.reduce((s,m)=>s+(m.metal_mute?.muted_traces||0),0),known_reference_enabled:false,known_exclusion_m:0,model:'v3 presence CNN + v1 horizontal localizer (ONNX)',checkpoint_sha256:runtime.checkpoint,device:'WebAssembly CPU',new_confirmed_leaks:0},warnings:options.metal_mute?[options.metal_mode==='auto_amplitude'?'Automatic amplitude-based mute was applied to every file. These ranges are not confirmed manholes; target signals and nearby reflections can also be suppressed.':'User-selected trace ranges were muted before detection. Strong-amplitude suggestions are not manhole labels.']:[]};
 }
 function trackGeometry(sgy){
  const n=sgy.n,length=new Float64Array(n-1),s=new Float64Array(n),positive=[];
  for(let i=0;i<n-1;i++){length[i]=Math.hypot(sgy.x[i+1]-sgy.x[i],sgy.y[i+1]-sgy.y[i]);if(length[i]>1e-9)positive.push(length[i]);s[i+1]=s[i]+length[i]}
  const spacing=median(positive),valid=Uint8Array.from(length,l=>l>1e-9&&l<=spacing*10),breaks=Uint8Array.from(length,l=>l>spacing*10);
  if(!valid.some(v=>v))throw Error('No continuous track with valid coordinates.');
  return {x:sgy.x,y:sgy.y,n,length,s,spacing,valid,breaks};
 }
 function search(a,value,right=false){let lo=0,hi=a.length;while(lo<hi){const m=(lo+hi)>>>1;if(a[m]<value||(right&&a[m]===value))lo=m+1;else hi=m}return lo}
 function project(track,target,preferred=null){
  const n=track.n-1,fractions=new Float64Array(n),distances=new Float64Array(n);let minimum=Infinity;
  for(let i=0;i<n;i++){
   if(!track.valid[i]){distances[i]=Infinity;continue}
   const dx=track.x[i+1]-track.x[i],dy=track.y[i+1]-track.y[i],fraction=clamp(((target[0]-track.x[i])*dx+(target[1]-track.y[i])*dy)/Math.max(track.length[i]**2,1e-20),0,1);
   fractions[i]=fraction;distances[i]=Math.hypot(track.x[i]+fraction*dx-target[0],track.y[i]+fraction*dy-target[1]);minimum=Math.min(minimum,distances[i]);
  }
  const tolerance=Math.max(track.spacing/2,1e-6),choices=[];let current=-1,last=-2;
  for(let i=0;i<n;i++)if(distances[i]<=minimum+tolerance){if(i!==last+1){if(current>=0)choices.push(current);current=i}else if(distances[i]<distances[current])current=i;last=i}
  if(current>=0)choices.push(current);choices.sort((a,b)=>distances[a]-distances[b]||a-b);
  let i=choices[0],anchored=false;
  if(preferred!==null){i=choices.reduce((best,k)=>Math.abs(k+fractions[k]-preferred)<Math.abs(best+fractions[best]-preferred)?k:best,choices[0]);anchored=choices.length>1}
  const fraction=fractions[i],nearest=fraction<.5?i:i+1;let lo=0,hi=track.n-1;
  for(let k=i-1;k>=0;k--)if(track.breaks[k]){lo=k+1;break}
  for(let k=i+1;k<n;k++)if(track.breaks[k]){hi=k;break}
  const centerS=track.s[i]+fraction*track.length[i],a=Math.max(lo,search(track.s,centerS-.5)),b=Math.min(hi,search(track.s,centerS+.5));
  let dx=b>a?track.x[b]-track.x[a]:track.x[i+1]-track.x[i],dy=b>a?track.y[b]-track.y[a]:track.y[i+1]-track.y[i];
  if(Math.hypot(dx,dy)<1e-9){dx=track.x[i+1]-track.x[i];dy=track.y[i+1]-track.y[i]}
  const norm=Math.hypot(dx,dy);
  return {segment:i,fraction,nearest,point:[track.x[i]+fraction*(track.x[i+1]-track.x[i]),track.y[i]+fraction*(track.y[i+1]-track.y[i])],distance:distances[i],centerS,lo,hi,tangent:[dx/norm,dy/norm],ambiguous:choices.length>1&&!anchored,anchorResolved:anchored,choices:choices.map(k=>({trace_1based:k+1+fractions[k],distance_m:distances[k]}))};
 }
 function physicalWindow(sgy,track,p,half,reverse=false,width=401){
  const ids=[],distances=[];for(let i=p.lo;i<=p.hi;i++)if(!distances.length||track.s[i]!==distances[distances.length-1]){ids.push(i);distances.push(track.s[i])}
  if(ids.length<2)throw Error('Insufficient continuous track samples.');
  const values=new Float32Array(sgy.ns*width);let covered=0;
  for(let c=0;c<width;c++){
   const target=p.centerS+(-half+2*half*c/(width-1))*(reverse?-1:1),inside=target>=distances[0]-1e-9&&target<=distances[distances.length-1]+1e-9;
   if(inside)covered++;
   const high=clamp(search(distances,target,true),1,ids.length-1),low=high-1,w=clamp((target-distances[low])/(distances[high]-distances[low]),0,1);
   for(let r=0;r<sgy.ns;r++)values[r*width+c]=inside?sgy.samples[ids[low]*sgy.ns+r]*(1-w)+sgy.samples[ids[high]*sgy.ns+r]*w:NaN;
  }
  return {values,width,height:sgy.ns,coverage:covered/width};
 }
 function distanceOrder(candidate,members){
  const rows=members.map((m,index)=>{
   const primary=m.file_id===candidate.file_id&&m.window_center_trace_1based===candidate.window_center_trace_1based&&m.trace_1based===candidate.trace_1based;
   const valid=[m.x,m.y,candidate.x,candidate.y].every(Number.isFinite),distance=valid?Math.hypot(m.x-candidate.x,m.y-candidate.y):m.file_id===candidate.file_id?Math.abs(m.trace_1based-candidate.trace_1based)*m.spacing_m:null;
   return {...m,primary,distance_to_primary_m:distance,distance_kind:valid?'xy':distance===null?'unknown':'along_track_estimate',source_index:index};
  });
  rows.sort((a,b)=>(a.distance_to_primary_m===null)-(b.distance_to_primary_m===null)||(a.distance_to_primary_m??Infinity)-(b.distance_to_primary_m??Infinity)||Number(b.primary)-Number(a.primary)||a.profile.localeCompare(b.profile)||(a.channel??-1)-(b.channel??-1)||a.trace_1based-b.trace_1based||a.source_index-b.source_index);
  rows.forEach((r,i)=>r.observation_id='O'+String(i+1).padStart(4,'0'));return rows;
 }
 return {roundEven,quantileAbs,median,parseSgy,metallicMask,selectedMetalMask,fileKey,fileMuteOptions,applyMetalMute,mutedSgyBytes,preprocess,groupPeaks,scanFiles,trackGeometry,project,physicalWindow,distanceOrder};
});
