'use strict';
let runtime=null,ready=null,cancelled=false,queue=Promise.resolve();
const sgyCache=new Map();
async function initialize(payload){
 if(!self.GprEngine)importScripts(payload.engineUrl);
 if(!self.GprRenderer)importScripts(payload.rendererUrl);
 if(!self.ort)importScripts(payload.runtimeBase+'ort.wasm.min.js');
 ort.env.wasm.numThreads=1;ort.env.wasm.wasmPaths=payload.runtimeBase;ort.env.wasm.proxy=false;
 const config={executionProviders:['wasm']};
 const presence=await ort.InferenceSession.create(payload.presence,config);
 const localizer=await ort.InferenceSession.create(payload.localizer,config);
 const run=async(session,values,n)=>Object.values(await session.run({input:new ort.Tensor('float32',values,[n,1,128,193])}))[0].data;
 runtime={presence:(v,n)=>run(presence,v,n),localizer:(v,n)=>run(localizer,v,n),checkpoint:payload.manifest.checkpoint_sha256};
 return {ready:true,execution_provider:'WebAssembly CPU'};
}
async function outputImage(image){return typeof OffscreenCanvas!=='undefined'?{file:image.file,blob:await GprRenderer.png(image)}:image}
async function loadSgy(file,spacing){
 if(sgyCache.has(file.id)){const value=sgyCache.get(file.id);sgyCache.delete(file.id);sgyCache.set(file.id,value);return value}
 const value=GprEngine.parseSgy(await file.file.arrayBuffer(),spacing);sgyCache.set(file.id,value);
 while(sgyCache.size>2)sgyCache.delete(sgyCache.keys().next().value);
 return value;
}
function traceWindow(sgy,center,half){
 const width=2*half+1,values=new Float32Array(sgy.ns*width);
 for(let c=0;c<width;c++)for(let r=0;r<sgy.ns;r++)values[r*width+c]=sgy.samples[Math.max(0,Math.min(sgy.n-1,center-half+c))*sgy.ns+r];
 return {values,width,height:sgy.ns,coverage:1};
}
async function initialViews(payload,progress){
 const outputs=[];
 const source=new Map(payload.files.map(f=>[f.id,f]));
 for(let i=0;i<payload.candidates.length;i++){
  const candidate=payload.candidates[i],rows=[candidate],used=new Set([candidate.channel]);
  for(const row of [...candidate._members].sort((a,b)=>b.logit-a.logit)){
   if(row.profile!==candidate.profile||used.has(row.channel))continue;
   rows.push(row);used.add(row.channel);if(rows.length>=3)break;
  }
  const panels=[];
  for(let k=0;k<rows.length;k++){
   const row=rows[k],sgy=await loadSgy(source.get(row.file_id),payload.spacing),half=Math.max(1,GprEngine.roundEven(4/sgy.spacing)),j=row.window_center_trace_1based-1,est=row.trace_1based-1;
   const file=`images/${candidate.candidate_id}_ch${row.channel}_${k}.png`;
   outputs.push(await outputImage({file,...traceWindow(sgy,j,half),half:4,blue:null,green:(est-j)/half*4,label:`${candidate.candidate_id} | CH ${row.channel} | full vertical record | green: AI center`}));
   panels.push({file,channel:row.channel,logit:row.logit,trace_1based:row.trace_1based,primary:k===0});
   if(k===0){const context=`images/${candidate.candidate_id}_context.png`;candidate.context_image=context;outputs.push(await outputImage({file:context,...traceWindow(sgy,est,Math.max(1,GprEngine.roundEven(8/sgy.spacing))),half:8,blue:null,green:0,label:`${candidate.candidate_id} | CH ${row.channel} | 16 m context | green: AI center`}))}
  }
  candidate.panels=panels;
  progress(.84+.15*(i+1)/Math.max(1,payload.candidates.length),`Preparing candidate views ${i+1}/${payload.candidates.length}`);
 }
 return {candidates:payload.candidates,images:outputs};
}
async function gallery(payload,progress){
 const candidate=payload.candidate,rows=GprEngine.distanceOrder(candidate,candidate._members),sources=new Map(payload.files.map(f=>[f.id,f]));
 const primary=await loadSgy(sources.get(candidate.file_id),payload.spacing),hasXY=Number.isFinite(candidate.x)&&Number.isFinite(candidate.y)&&primary.coordinateAvailable;
 let tangent=null;
 if(hasXY){const track=GprEngine.trackGeometry(primary);tangent=GprEngine.project(track,[candidate.x,candidate.y],candidate.trace_1based-1).tangent}
 const images=[],aligned=[],fileIds=[...new Set(rows.map(r=>r.file_id))];
 const warnings=[hasXY?'Aligned using recorded SGY source XY; absolute antenna positions and lever-arm calibration have not been independently verified.':'XY is unavailable. Views use the same recorded candidate trace within the source file; cross-file spatial alignment is unavailable.'];
 for(let fi=0;fi<fileIds.length;fi++){
  const fid=fileIds[fi],sgy=await loadSgy(sources.get(fid),payload.spacing),members=rows.filter(r=>r.file_id===fid);
  let small,large,p,reverse=false,angle=0,shared;
  if(hasXY&&sgy.coordinateAvailable){
   const track=GprEngine.trackGeometry(sgy);p=GprEngine.project(track,[candidate.x,candidate.y],fid===candidate.file_id?candidate.trace_1based-1:null);
   const dot=Math.max(-1,Math.min(1,tangent[0]*p.tangent[0]+tangent[1]*p.tangent[1]));reverse=dot<0;angle=Math.acos(Math.abs(dot))*180/Math.PI;
   small=GprEngine.physicalWindow(sgy,track,p,4,reverse);large=GprEngine.physicalWindow(sgy,track,p,8,reverse);
   shared={alignment_version:4,alignment:'nearest_track_projection',alignment_target_x:candidate.x,alignment_target_y:candidate.y,alignment_trace_1based:p.nearest+1,alignment_fractional_trace_1based:p.segment+1+p.fraction,alignment_x:p.point[0],alignment_y:p.point[1],alignment_distance_m:p.distance,alignment_sample_x:sgy.x[p.nearest],alignment_sample_y:sgy.y[p.nearest],alignment_sample_distance_m:Math.hypot(sgy.x[p.nearest]-candidate.x,sgy.y[p.nearest]-candidate.y),alignment_ambiguous:p.ambiguous,alignment_choices:p.choices,alignment_primary_trace_resolved:p.anchorResolved,display_reversed:reverse,relative_track_angle_degrees:angle,window_width_m:8,context_width_m:16,coverage_fraction:small.coverage,context_coverage_fraction:large.coverage,samples_per_trace:sgy.ns};
   for(const member of members){
    const row={...member,...shared},ai=member.trace_1based-1,offset=ai>=p.lo&&ai<=p.hi?(track.s[ai]-p.centerS)*(reverse?-1:1):null;
    Object.assign(row,{view_kind:'merged',line_kind:'spatial_alignment',source_observation_id:member.observation_id,ai_offset_from_alignment_m:offset,ai_inside_window:offset!==null&&Math.abs(offset)<=4});
    const stem=`images/aligned_v4/${candidate.candidate_id}/${fid}/${member.observation_id}`;
    row.file=stem+'.png';row.context_image=stem+'_context.png';aligned.push(row);
    const label=`${candidate.candidate_id} | CH ${row.channel} | fixed primary XY | blue: alignment | green dashed: AI center`;
    images.push(await outputImage({file:row.file,...small,half:4,blue:0,green:offset,dashed:true,label}),await outputImage({file:row.context_image,...large,half:8,blue:0,green:offset,dashed:true,label}));
   }
   if(p.ambiguous)warnings.push(`CH${members[0].channel}: multiple possible track matches; check the displayed alignment.`);
  }else{
   const center=candidate.trace_1based-1;small=traceWindow(sgy,center,Math.max(1,GprEngine.roundEven(4/sgy.spacing)));large=traceWindow(sgy,center,Math.max(1,GprEngine.roundEven(8/sgy.spacing)));
   for(const member of members){
    const offset=(member.trace_1based-candidate.trace_1based)*sgy.spacing,stem=`images/trace_aligned/${candidate.candidate_id}/${fid}/${member.observation_id}`;
    const row={...member,alignment_version:0,alignment_trace_1based:candidate.trace_1based,samples_per_trace:sgy.ns,view_kind:'merged',source_observation_id:member.observation_id,ai_offset_from_alignment_m:offset,ai_inside_window:Math.abs(offset)<=4,file:stem+'.png',context_image:stem+'_context.png'};
    aligned.push(row);const label=`${candidate.candidate_id} | CH ${row.channel} | same-file trace alignment | dashed green: AI center`;
    images.push(await outputImage({file:row.file,...small,half:4,blue:0,green:offset,dashed:true,label}),await outputImage({file:row.context_image,...large,half:8,blue:0,green:offset,dashed:true,label}));
   }
  }
  progress((fi+1)/fileIds.length,`Aligning merged-hit channels ${fi+1}/${fileIds.length}`);
 }
 const byChannel=new Map(),profiles=new Map();
 for(const row of aligned){
  if(row.profile===candidate.profile){const key=row.channel??row.file_id;if(!byChannel.has(key))byChannel.set(key,[]);byChannel.get(key).push(row)}
  else {if(!profiles.has(row.profile))profiles.set(row.profile,[]);profiles.get(row.profile).push(row)}
 }
 const sortRows=(a,b)=>(a.channel??Infinity)-(b.channel??Infinity)||(a.distance_to_primary_m??Infinity)-(b.distance_to_primary_m??Infinity)||a.trace_1based-b.trace_1based;
 const main_rows=[...byChannel.values()].map(variants=>{variants.sort((a,b)=>Number(b.primary)-Number(a.primary)||(a.distance_to_primary_m??Infinity)-(b.distance_to_primary_m??Infinity)||a.name.localeCompare(b.name)||a.trace_1based-b.trace_1based);return {...variants[0],aligned_alternatives:variants,view_id:'M_'+variants[0].file_id}}).sort(sortRows);
 const groups=[...profiles].map(([profile,views])=>({profile,primary_swath:false,alignment_version:hasXY?4:0,nearest_distance_m:Math.min(...views.map(r=>r.alignment_distance_m??Infinity)),rows:views.sort(sortRows)})).sort((a,b)=>a.nearest_distance_m-b.nearest_distance_m||a.profile.localeCompare(b.profile));
 return {rows,main_rows,groups,warnings,images,alignment_audit:{version:hasXY?4:0,target_xy:hasXY?[candidate.x,candidate.y]:null,coordinate_reference:hasXY?'recorded source XY':'same-file trace',antenna_calibration_verified:false}};
}
self.onmessage=event=>{
 const {id,type,payload}=event.data;
 if(type==='cancel'){cancelled=true;return}
 const progress=(value,message)=>self.postMessage({id,event:'progress',progress:value,message});
 queue=queue.catch(()=>{}).then(async()=>{
  try{
   let result;
   if(type==='init'){if(!ready)ready=initialize(payload);result=await ready}
   else {await ready;if(!runtime)throw Error('Model runtime is not ready.');
    if(type==='scan'){cancelled=false;sgyCache.clear();result=await GprEngine.scanFiles(payload.files,payload.options,runtime,progress,()=>cancelled)}
    else if(type==='images')result=await initialViews(payload,progress);
    else if(type==='gallery')result=await gallery(payload,progress);
    else throw Error('Unknown worker operation.');
   }
   self.postMessage({id,result});
  }catch(error){self.postMessage({id,error:error.message||String(error)})}
 });
};
