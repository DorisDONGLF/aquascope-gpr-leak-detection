/* Header-only track geometry. No artificial antenna offsets are introduced. */
(function(root,factory){const value=factory(root.GprEngine||(typeof require==='function'?require('./engine.js'):null));if(typeof module==='object'&&module.exports)module.exports=value;else root.GprSpatial=value})(typeof self!=='undefined'?self:globalThis,function(core){
 'use strict';
 function parseTrack(buffer,fallback=.04){
  const v=ArrayBuffer.isView(buffer)?new DataView(buffer.buffer,buffer.byteOffset,buffer.byteLength):new DataView(buffer);if(v.byteLength<3840)throw Error('SGY is too short.');
  const ns=v.getUint16(3220),format=v.getUint16(3224),ext=v.getInt16(3504);if(format!==2||!ns||ns>20000||ext<0||ext>100)throw Error('Unsupported SGY header layout.');
  const offset=3600+ext*3200,stride=240+4*ns,n=(v.byteLength-offset)/stride;if(!Number.isInteger(n)||n<2)throw Error('Inconsistent SGY trace layout.');
  const x=new Float64Array(n),y=new Float64Array(n),units=new Set(),steps=[];let nonzero=false;
  for(let i=0;i<n;i++){const p=offset+i*stride,scalar=v.getInt16(p+70),scale=scalar>0?scalar:1/Math.max(1,Math.abs(scalar));x[i]=v.getInt32(p+72)*scale;y[i]=v.getInt32(p+76)*scale;nonzero||=x[i]!==0||y[i]!==0;units.add(v.getUint16(p+88));if(i){const d=Math.hypot(x[i]-x[i-1],y[i]-y[i-1]);if(d>.001&&d<10)steps.push(d)}}
  const coordinateAvailable=nonzero&&steps.length>0&&[...units].every(u=>u<=1)&&v.getUint16(3254)!==2;
  return {x,y,n,ns,coordinateAvailable,spacing:coordinateAvailable?core.median(steps):fallback};
 }
 const hongKong=(x,y)=>Number.isFinite(x)&&Number.isFinite(y)&&x>=790000&&x<=875000&&y>=795000&&y<=855000;
 function sqDistance(p,a,b){const dx=b[0]-a[0],dy=b[1]-a[1],d=dx*dx+dy*dy,t=d?Math.max(0,Math.min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/d)):0;return (p[0]-a[0]-t*dx)**2+(p[1]-a[1]-t*dy)**2}
 function simplify(points,tolerance=.02){
  if(points.length<3)return points;const keep=new Uint8Array(points.length);keep[0]=keep[points.length-1]=1;const stack=[[0,points.length-1]];
  while(stack.length){const [a,b]=stack.pop();let best=tolerance*tolerance,index=-1;for(let i=a+1;i<b;i++){const d=sqDistance(points[i],points[a],points[b]);if(d>best){best=d;index=i}}if(index>=0){keep[index]=1;stack.push([a,index],[index,b])}}
  return points.filter((_,i)=>keep[i]);
 }
 function describe(file,sgy){
  const match=/-(\d+)\.(?:sgy|segy)$/i.exec(file.name),base={file_id:file.id,name:file.name,profile:match?file.name.slice(0,match.index):file.name.replace(/\.[^.]+$/,''),channel:match?Number(match[1]):null,traces:sgy.n,paths:[]};
  if(!sgy.coordinateAvailable)return {...base,unavailable:'Reliable metric source XY is unavailable.'};
  const track=core.trackGeometry(sgy),paths=[];let current=[];
  for(let i=0;i<sgy.n;i++){
   if(!hongKong(sgy.x[i],sgy.y[i])){if(current.length>1)paths.push(simplify(current));current=[];continue}
   if(i&&track.breaks[i-1]){if(current.length>1)paths.push(simplify(current));current=[]}
   if(!current.length||Math.hypot(current[current.length-1][0]-sgy.x[i],current[current.length-1][1]-sgy.y[i])>1e-8)current.push([sgy.x[i],sgy.y[i]]);
  }
  if(current.length>1)paths.push(simplify(current));
  const warnings=[];if(!paths.length)warnings.push('Coordinates are outside the confirmed EPSG:2326 area or contain no continuous track.');
  return {...base,paths,display_tolerance_m:.02,warnings,first_xy:hongKong(sgy.x[0],sgy.y[0])?[sgy.x[0],sgy.y[0]]:null,last_xy:hongKong(sgy.x[sgy.n-1],sgy.y[sgy.n-1])?[sgy.x[sgy.n-1],sgy.y[sgy.n-1]]:null};
 }
 function sample(track,distance,lo,hi){
  let a=lo,b=hi;while(a<b){const m=(a+b)>>>1;if(track.s[m]<distance)a=m+1;else b=m}const high=Math.max(lo+1,Math.min(hi,a)),low=high-1,d=track.s[high]-track.s[low],w=d?Math.max(0,Math.min(1,(distance-track.s[low])/d)):0;return [track.x[low]*(1-w)+track.x[high]*w,track.y[low]*(1-w)+track.y[high]*w];
 }
 function footprint(sgy,row,candidate){
  if(!sgy.coordinateAvailable||row.alignment_version!==4)return {available:false,reason:'An aligned view with recorded metric XY is required.'};
  const track=core.trackGeometry(sgy),anchor=Number.isFinite(row.alignment_fractional_trace_1based)?row.alignment_fractional_trace_1based-1:null,p=core.project(track,[candidate.x,candidate.y],anchor),start=Math.max(track.s[p.lo],p.centerS-4),end=Math.min(track.s[p.hi],p.centerS+4),points=[sample(track,start,p.lo,p.hi)];
  for(let i=p.lo;i<=p.hi;i++)if(track.s[i]>start&&track.s[i]<end)points.push([track.x[i],track.y[i]]);points.push(sample(track,end,p.lo,p.hi));
  const reversed=!!row.display_reversed,leftS=Math.max(start,Math.min(end,p.centerS+(reversed?4:-4))),rightS=Math.max(start,Math.min(end,p.centerS+(reversed?-4:4))),left=sample(track,leftS,p.lo,p.hi),right=sample(track,rightS,p.lo,p.hi);
  return {available:true,file_id:row.file_id,profile:row.profile,channel:row.channel,path:points,center:[row.alignment_x,row.alignment_y],left,right,left_offset_m:(leftS-p.centerS)*(reversed?-1:1),right_offset_m:(rightS-p.centerS)*(reversed?-1:1),ai:hongKong(row.x,row.y)?[row.x,row.y]:null,display_reversed:reversed,coverage_fraction:row.coverage_fraction,alignment_ambiguous:!!row.alignment_ambiguous};
 }
 return {parseTrack,hongKong,simplify,describe,footprint};
});
