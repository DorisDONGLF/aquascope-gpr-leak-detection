(function(){
 'use strict';let generation=0;
 async function refresh(files,busy){
  const version=++generation,snapshot=files.slice(),box=document.getElementById('importCapacity');
  if(!snapshot.length){box.textContent='Up to 1,024 files per run. Files are scanned one at a time.';return}
  const info=GprCapacity.evaluate(snapshot,null);box.textContent=`${snapshot.length.toLocaleString()} / 1,024 files · ${GprCapacity.formatBytes(info.total)} selected · Checking browser storage…`;
  const result=GprCapacity.evaluate(snapshot,await GprCapacity.estimateStorage());if(version!==generation)return;
  const prefix=`${snapshot.length.toLocaleString()} / 1,024 files · ${GprCapacity.formatBytes(result.total)} selected`;
  box.textContent=prefix+(result.available===null?' · Browser storage estimate unavailable.':` · Browser storage available: ${GprCapacity.formatBytes(result.available)}.`);
  if(result.status==='insufficient')box.textContent+=' The source files exceed available storage; choose a smaller batch.';
  else if(result.status==='tight')box.textContent+=' Limited room for result images; a smaller batch is recommended.';
  else box.textContent+=' Files are scanned one at a time; result images need additional space.';
  document.getElementById('startBtn').disabled=busy||result.status==='insufficient';
 }
 window.GprCapacityUI={refresh};refresh(files,busy);
})();
