/* Local SGY channel plans. Geometry is never displaced to separate labels. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.GprChannelPlan=api})(typeof self!=='undefined'?self:globalThis,function(){
 'use strict';let serial=0;
 function nearest(paths,target){let best=null;for(let k=0;k<(paths||[]).length;k++){const path=paths[k];let s=0;for(let i=1;i<path.length;i++){const a=path[i-1],b=path[i],dx=b[0]-a[0],dy=b[1]-a[1],length=Math.hypot(dx,dy);if(!length)continue;const t=Math.max(0,Math.min(1,((target[0]-a[0])*dx+(target[1]-a[1])*dy)/(length*length))),point=[a[0]+t*dx,a[1]+t*dy],distance=Math.hypot(point[0]-target[0],point[1]-target[1]);if(!best||distance<best.distance)best={point,distance,tangent:[dx/length,dy/length],pathIndex:k,s:s+t*length};s+=length}}return best}
 function context(paths,near,half=4){const path=paths[near.pathIndex],out=[];let s=0;for(let i=1;i<path.length;i++){const a=path[i-1],b=path[i],length=Math.hypot(b[0]-a[0],b[1]-a[1]);if(!length)continue;const lo=Math.max(s,near.s-half),hi=Math.min(s+length,near.s+half);if(hi>=lo){for(const d of [lo,hi]){const t=(d-s)/length,p=[a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1])];if(!out.length||Math.hypot(out.at(-1)[0]-p[0],out.at(-1)[1]-p[1])>1e-8)out.push(p)}}s+=length}return out}
 function labels(entries,width){const sorted=[...entries].sort((a,b)=>a.local[0]-b.local[0]||(a.track.channel??Infinity)-(b.track.channel??Infinity)||a.track.name.localeCompare(b.track.name));return sorted.map((entry,i)=>({file_id:entry.track.file_id,label:'CH'+(entry.track.channel??'?'),x:70+(width-140)*(i+.5)/Math.max(1,sorted.length),entry}))}
 function build(data,candidate,profile,rows=[],activeRow=null,window=null){
  const target=[candidate.x,candidate.y],primary=data.tracks.find(t=>t.file_id===candidate.file_id),basis=nearest(primary?.paths,target);if(!basis)return {available:false,reason:'Reliable primary-track geometry is unavailable.'};
  const f=basis.tangent,n=[f[1],-f[0]],local=p=>{const dx=p[0]-target[0],dy=p[1]-target[1];return [dx*n[0]+dy*n[1],dx*f[0]+dy*f[1]]},compare=profile!==candidate.profile;
  const entries=data.tracks.filter(t=>(t.profile===candidate.profile||t.profile===profile)&&t.paths?.length).map(track=>{const row=rows.find(r=>r.file_id===track.file_id&&r.alignment_version===4),near=nearest(track.paths,row?[row.alignment_x,row.alignment_y]:target);if(!near)return null;const point=row?[row.alignment_x,row.alignment_y]:near.point,active=track.file_id===activeRow?.file_id,path=active&&window?.available?window.path:context(track.paths,near);return {track,row,point,local:local(point),distance:row?row.alignment_distance_m:near.distance,exact:!!row,active,path,localPath:path.map(local),primary:track.profile===candidate.profile}}).filter(Boolean);
  const primaryEntries=entries.filter(e=>e.primary),otherEntries=entries.filter(e=>!e.primary),width=Math.max(740,140+Math.max(primaryEntries.length,otherEntries.length)*42),height=460;
  const positions=entries.flatMap(e=>[e.local,...e.localPath]);positions.push([0,0]);const xMin=Math.min(-.35,...positions.map(p=>p[0]))-.15,xMax=Math.max(.35,...positions.map(p=>p[0]))+.15,yMin=Math.min(-4,...positions.map(p=>p[1]))-.5,yMax=Math.max(4,...positions.map(p=>p[1]))+.5;
  // Both swaths share the same XY frame. Labels have separate slots and leaders.
  const X=p=>60+(p[0]-xMin)/(xMax-xMin)*(width-120),Y=p=>365-(p[1]-yMin)/(yMax-yMin)*260;
  return {available:true,target,profile,compare,width,height,entries,primaryEntries,otherEntries,xMin,xMax,yMin,yMax,X,Y,local,topLabels:labels(primaryEntries,width),bottomLabels:labels(otherEntries,width),candidateScreen:[X([0,0]),Y([0,0])],coincident:entries.length-new Set(entries.map(e=>JSON.stringify(e.track.paths))).size};
 }
 function render(host,plan,options={}){
  host.replaceChildren();if(!plan.available){host.textContent=plan.reason;return}
  const ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg'),id='channelPlanClip'+(++serial);svg.setAttribute('viewBox',`0 0 ${plan.width} ${plan.height}`);svg.setAttribute('role','img');svg.setAttribute('aria-label',plan.compare?'Channel relationship: '+plan.profile+' and primary swath':'Primary swath channel relationship');svg.style.width=plan.width+'px';
  const append=(tag,attrs,text,parent=svg)=>{const el=document.createElementNS(ns,tag);for(const [k,v]of Object.entries(attrs))el.setAttribute(k,v);if(text!==undefined)el.textContent=text;parent.append(el);return el},title=(el,text)=>append('title',{},text,el);
  const defs=append('defs',{}),clip=append('clipPath',{id},undefined,defs);append('rect',{x:50,y:95,width:plan.width-100,height:280},undefined,clip);
  append('rect',{x:0,y:0,width:plan.width,height:plan.height,fill:'#181b20'});
  append('text',{x:18,y:22,fill:'#c5d4e2','font-size':12},'Along primary record ↑ · Across-track positions (m)');
  append('text',{x:18,y:42,fill:'#99aaba','font-size':11},'Axes fitted independently · Label leaders point to recorded positions');
  append('text',{x:18,y:63,fill:'#58a7ed','font-size':12},'Primary swath channels');
  const group=append('g',{'clip-path':`url(#${id})`});
  append('line',{x1:50,y1:plan.Y([0,0]),x2:plan.width-50,y2:plan.Y([0,0]),stroke:'#67717c','stroke-dasharray':'4 4'},undefined,group);
  for(const e of plan.entries){const color=e.primary?'#58a7ed':'#f1a34a',d=e.localPath.map((p,i)=>(i?'L':'M')+plan.X(p).toFixed(2)+','+plan.Y(p).toFixed(2)).join(' ');const path=append('path',{d,fill:'none',stroke:e.active?'#64e4bd':color,'stroke-width':e.active?3:1.5},undefined,group);title(path,`${e.primary?'Primary':'This swath'} · CH${e.track.channel} · ${e.track.name}`);path.style.cursor='pointer';path.onclick=()=>options.onFile?.(e.track);
   const dot=append('circle',{cx:plan.X(e.local),cy:plan.Y(e.local),r:e.active?4.5:3,fill:color},undefined,group);title(dot,`${e.track.profile} · CH${e.track.channel} · ${e.distance.toFixed(3)} m from Candidate center`);dot.style.cursor='pointer';dot.onclick=()=>options.onFile?.(e.track);
  }
  const band=(items,top)=>{for(const v of items){const e=v.entry,x=plan.X(e.local),y=plan.Y(e.local),labelY=top?83:410,color=e.primary?'#58a7ed':'#f1a34a';append('polyline',{points:`${x},${y} ${x},${top?97:383} ${v.x},${top?92:394}`,fill:'none',stroke:color,'stroke-width':.7,opacity:.55});const label=append('text',{x:v.x,y:labelY,fill:e.active?'#64e4bd':color,'font-size':12,'text-anchor':'middle','data-plan-channel':e.track.file_id},v.label);title(label,e.track.name);label.style.cursor='pointer';label.onclick=()=>options.onFile?.(e.track)}};
  band(plan.topLabels,true);band(plan.bottomLabels,false);
  const [cx,cy]=plan.candidateScreen;append('circle',{cx,cy,r:7,fill:'#ff5f75',stroke:'#fff','stroke-width':1.5,'data-candidate-center':'true'});append('rect',{x:cx-60,y:cy-30,width:120,height:20,rx:5,fill:'#30252e',stroke:'#ff5f75','stroke-width':.6});append('text',{x:cx,y:cy-16,fill:'#ffb4bf','font-size':12,'text-anchor':'middle'},'Candidate center');
  for(const value of [plan.xMin,0,plan.xMax])append('text',{x:plan.X([value,0]),y:433,fill:'#a9b8c8','font-size':10,'text-anchor':'middle'},value.toFixed(2)+' m');
  append('text',{x:10,y:115,fill:'#a9b8c8','font-size':10},'+'+plan.yMax.toFixed(1)+' m');append('text',{x:10,y:370,fill:'#a9b8c8','font-size':10},plan.yMin.toFixed(1)+' m');
  if(plan.compare)append('text',{x:18,y:452,fill:'#f1a34a','font-size':11},'Lower labels: this swath · Blue: primary · Green: selected channel context');else append('text',{x:18,y:452,fill:'#a9b8c8','font-size':11},'Blue: primary channels · Green: selected channel context');
  host.append(svg);
  const note=document.createElement('p');note.className='channel-plan-note';note.textContent=plan.coincident?'Some channels share recorded XY. Separate labels do not imply separate antenna positions.':'Recorded source XY · The red Candidate center stays fixed when channels or swaths change.';host.append(note);
 }
 return {nearest,context,labels,build,render};
});
