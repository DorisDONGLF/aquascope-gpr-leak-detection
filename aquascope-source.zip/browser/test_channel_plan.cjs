const assert=require('node:assert/strict'),P=require('./channel_plan.js');
const origin=[835970,815900],tracks=[];for(const [profile,dx]of [['main',0],['other',2]])for(let ch=1;ch<=18;ch++)tracks.push({file_id:profile+ch,name:profile+'-'+ch+'.SGY',profile,channel:ch,paths:[[[origin[0]+dx+(ch-9)*.08,origin[1]-20],[origin[0]+dx+(ch-9)*.08,origin[1]+20]]]});
const candidate={x:origin[0],y:origin[1],profile:'main',file_id:'main9'},row={observation_id:'o',file_id:'other8',profile:'other',channel:8};
const plan=P.build({tracks},candidate,'other',[],row);
assert.equal(plan.entries.length,36);assert.equal(plan.topLabels.length,18);assert.equal(plan.bottomLabels.length,18);assert.deepEqual(plan.target,origin);assert.deepEqual(plan.entries.find(e=>e.track.file_id==='main9').point,origin);
for(const band of [plan.topLabels,plan.bottomLabels])for(let i=1;i<band.length;i++)assert(band[i].x-band[i-1].x>=40,'Channel names need separate label slots');
const reverse={...tracks[0],file_id:'reverse',channel:19,paths:tracks[0].paths.map(p=>[...p].reverse())};const r=P.build({tracks:[...tracks,reverse]},candidate,'main');assert.deepEqual(r.entries.find(e=>e.track.file_id==='reverse').point,r.entries.find(e=>e.track.file_id==='main1').point);assert.equal(r.coincident,0); // Path order differs; no XY displacement is introduced.
const duplicate={...tracks[0],file_id:'copy',channel:20},dup=P.build({tracks:[...tracks,duplicate]},candidate,'main');assert.equal(dup.coincident,1);assert.deepEqual(dup.entries.find(e=>e.track.file_id==='copy').point,dup.entries.find(e=>e.track.file_id==='main1').point);
const selectedPath=[[origin[0]+1.92,origin[1]-4],[origin[0]+1.92,origin[1]+4]],exact=P.build({tracks},candidate,'other',[],row,{available:true,path:selectedPath});assert.deepEqual(exact.entries.find(e=>e.active).path,selectedPath);
assert.deepEqual(P.build({tracks},candidate,'main').target,plan.target);assert.equal(P.build({tracks:[]},candidate,'other').available,false);
console.log(JSON.stringify({passed:true,primaryChannels:18,nearbyChannels:18,labelSpacing:'>=40 px',fixedCenterPreserved:true,coincidentCoordinatesUnchanged:true,activeFootprintPreserved:true}));
