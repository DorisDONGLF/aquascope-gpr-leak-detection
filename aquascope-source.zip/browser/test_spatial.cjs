const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),core=require('./engine.js'),spatial=require('./spatial.js');
function fixture(){const n=301,ns=8,stride=272,bytes=new Uint8Array(3600+n*stride),v=new DataView(bytes.buffer);v.setUint16(3220,ns);v.setUint16(3224,2);for(let i=0;i<n;i++){const p=3600+i*stride;v.setInt16(p+70,-1000);v.setInt32(p+72,822000000+i*100);v.setInt32(p+76,838000000);v.setUint16(p+114,ns)}return bytes}
const bytes=fixture(),full=core.parseSgy(bytes),headers=spatial.parseTrack(bytes);assert.deepEqual(headers.x,full.x);assert.deepEqual(headers.y,full.y);assert.equal(headers.spacing,full.spacing);
const descriptor=spatial.describe({id:'a',name:'swath-4.SGY'},headers);assert.deepEqual(descriptor.paths,[[[822000,838000],[822030,838000]]]);
const row={file_id:'a',profile:'swath',channel:4,alignment_version:4,alignment_fractional_trace_1based:151,alignment_x:822015,alignment_y:838000,x:822015.3,y:838000,coverage_fraction:1},candidate={x:822015,y:838000};
const w=spatial.footprint(headers,row,candidate);assert.deepEqual(w.left,[822011,838000]);assert.deepEqual(w.right,[822019,838000]);assert.equal(w.left_offset_m,-4);assert.equal(w.right_offset_m,4);
const reversed=spatial.footprint(headers,{...row,display_reversed:true},candidate);assert.deepEqual(reversed.left,w.right);assert.deepEqual(reversed.right,w.left);
const edge=spatial.footprint(headers,{...row,alignment_fractional_trace_1based:6,alignment_x:822000.5},{x:822000.5,y:838000});assert.deepEqual(edge.left,[822000,838000]);assert(Math.abs(edge.left_offset_m+.5)<1e-8);
assert.equal(spatial.footprint(headers,{...row,alignment_version:0},candidate).available,false);
const jump=spatial.parseTrack(bytes);for(let i=151;i<jump.n;i++)jump.x[i]+=100;assert.equal(spatial.describe({id:'j',name:'j-4.SGY'},jump).paths.length,2,'GPS gaps must not be joined');
const repeated=spatial.describe({id:'copy',name:'swath-5.SGY'},headers);assert.deepEqual(repeated.paths,descriptor.paths,'No antenna offsets may be invented');
let realFiles=0;const qa=process.argv[2];if(qa){for(const name of fs.readdirSync(qa).filter(n=>n.endsWith('.SGY'))){const buffer=fs.readFileSync(path.join(qa,name)),a=core.parseSgy(buffer),b=spatial.parseTrack(buffer);assert.deepEqual(b.x,a.x);assert.deepEqual(b.y,a.y);assert.equal(b.coordinateAvailable,a.coordinateAvailable);realFiles++}}
console.log(JSON.stringify({all_passed:true,real_header_parity_files:realFiles,footprint_edges_and_reversal:true,discontinuities_preserved:true,no_offsets_invented:true}));
