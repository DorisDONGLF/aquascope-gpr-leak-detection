/* The existing interface talks to an IndexedDB/worker adapter, never a server API. */
(function(){
 'use strict';
 const nativeFetch=window.fetch.bind(window),baseUrl=new URL('./',location.href),tabId=crypto.randomUUID();
 const objectUrls=new Map(),runningJobs=new Set(),observationTasks=new Map();
 let currentAssetJob=null,worker=null,workerReady=null,rpcId=0;
 const pending=new Map(),LABELS=new Set(['unreviewed','similar','different','manhole','uncertain']);
 const placeholder='data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="1100" height="470"><rect width="100%" height="100%" fill="#242024"/><text x="50%" y="50%" text-anchor="middle" fill="#c9bfc2" font-family="sans-serif">Image unavailable</text></svg>');
 const dbReady=new Promise((resolve,reject)=>{
  const req=indexedDB.open('aquascope-gpr-browser-v1',1);
  req.onupgradeneeded=()=>{
   const db=req.result;
   db.createObjectStore('jobs',{keyPath:'id'});db.createObjectStore('uploads',{keyPath:'id'});
   const assets=db.createObjectStore('assets',{keyPath:'key'});assets.createIndex('job_id','job_id');
   const scores=db.createObjectStore('scores',{keyPath:'key'});scores.createIndex('job_id','job_id');
  };
  req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(Error('Browser storage is unavailable. Open this page in a normal Chrome or Edge window.'));
 });
 async function store(name,mode,action){
  const db=await dbReady;
  return new Promise((resolve,reject)=>{
   const transaction=db.transaction(name,mode),request=action(transaction.objectStore(name));
   transaction.oncomplete=()=>resolve(request?.result);
   transaction.onerror=transaction.onabort=()=>reject(Error(transaction.error?.name==='QuotaExceededError'?'Browser storage is full. Export your work and free site storage before retrying.':transaction.error?.message||'Could not save browser data.'));
  });
 }
 const get=(name,key)=>store(name,'readonly',s=>s.get(key)),put=(name,value)=>store(name,'readwrite',s=>s.put(value)),all=name=>store(name,'readonly',s=>s.getAll());
 async function withJobLock(id,action){return navigator.locks?navigator.locks.request('aquascope-job-'+id,action):action()}
 function heartbeat(){try{if(runningJobs.size)localStorage.setItem('aquascope-tab-'+tabId,String(Date.now()));else localStorage.removeItem('aquascope-tab-'+tabId)}catch{}}
 setInterval(heartbeat,5000);
 window.addEventListener('pagehide',()=>{try{localStorage.removeItem('aquascope-tab-'+tabId)}catch{}});
 async function readJob(id){
  const job=await get('jobs',id);if(!job)throw Error('Detection run not found in this browser.');
  if(['queued','running'].includes(job.status)&&!runningJobs.has(id)){
   let alive=false;try{alive=Date.now()-Number(localStorage.getItem('aquascope-tab-'+job.runtime_tab_id)||0)<30000}catch{}
   if(!alive){job.status='error';job.message='Detection stopped when its browser tab closed. Choose the SGY files to run again.';await put('jobs',job)}
  }
  return job;
 }
 async function sourceFiles(job){
  return Promise.all(job.input_files.map(async f=>{const upload=await get('uploads',f.id);if(!upload?.file)throw Error('The original SGY file is no longer available in browser storage.');return upload}));
 }
 function requestWorker(type,payload,progress){
  const id=++rpcId;
  return new Promise((resolve,reject)=>{pending.set(id,{resolve,reject,progress});worker.postMessage({id,type,payload})});
 }
 function decode64(value){const binary=atob(value),out=new Uint8Array(binary.length);for(let i=0;i<binary.length;i++)out[i]=binary.charCodeAt(i);return out}
 function toolsWorker(){
  if(worker)return worker;
  if(!globalThis.Worker)throw Error('Use a current desktop Chrome or Edge browser.');
  const config=window.GPR_BROWSER_BUNDLE,source=config?URL.createObjectURL(new Blob([config.workerSource],{type:'text/javascript'})):new URL('worker.js',baseUrl).href;
  worker=new Worker(source);if(config)URL.revokeObjectURL(source);
  worker.onmessage=event=>{const message=event.data,task=pending.get(message.id);if(!task)return;if(message.event==='progress'){task.progress?.(message.progress,message.message);return}pending.delete(message.id);message.error?task.reject(Error(message.error)):task.resolve(message.result)};
  worker.onerror=event=>{const error=Error(event.message||'The model worker stopped unexpectedly. Reload the page and retry.');for(const task of pending.values())task.reject(error);pending.clear();workerReady=null;worker=null};
  return worker;
 }
 async function metallicOperation(type,file,threshold,spacing=.04,ranges=[]){
  toolsWorker();const payload={file,threshold,spacing,ranges,engineUrl:new URL('engine.js',baseUrl).href,rendererUrl:new URL('renderer.js',baseUrl).href};
  return requestWorker(type,payload);
 }
 async function ensureWorker(){
  if(workerReady)return workerReady;
  workerReady=(async()=>{
   const config=window.GPR_BROWSER_BUNDLE,manifest=config?.manifest||await (await nativeFetch(new URL('models/manifest.json',baseUrl))).json();
   const presence=config?decode64(config.models.presence):new Uint8Array(await (await nativeFetch(new URL('models/'+manifest.presence.file,baseUrl))).arrayBuffer());
   const localizer=config?decode64(config.models.localizer):new Uint8Array(await (await nativeFetch(new URL('models/'+manifest.localizer.file,baseUrl))).arrayBuffer());
   if(!globalThis.Worker||!globalThis.WebAssembly)throw Error('This browser cannot run the model. Use a current desktop Chrome or Edge browser.');
   toolsWorker();
   const payload={manifest,presence,localizer,engineUrl:new URL('engine.js',baseUrl).href,rendererUrl:new URL('renderer.js',baseUrl).href,runtimeBase:config?.runtimeBase||new URL('vendor/onnxruntime/',baseUrl).href};
   await requestWorker('init',payload);
   return manifest;
  })().catch(error=>{workerReady=null;worker?.terminate();worker=null;throw Error('Could not load the on-device model. Check the connection and retry. '+error.message)});
  return workerReady;
 }
 async function saveAsset(jobId,file,blob){
  const key=jobId+'/'+file;await put('assets',{key,job_id:jobId,file,blob});
  if(currentAssetJob===jobId){if(objectUrls.has(key))URL.revokeObjectURL(objectUrls.get(key));objectUrls.set(key,URL.createObjectURL(blob))}
 }
 async function saveImages(jobId,images,progress){
  for(let i=0;i<images.length;i++){
   const image=images[i],blob=image.blob||await GprRenderer.png(image);await saveAsset(jobId,image.file,blob);
   if(i%8===0)progress?.((i+1)/images.length,`Saving PNG views ${i+1}/${images.length}`);
  }
 }
 async function hydrateAssets(jobId){
  if(currentAssetJob!==jobId){
   for(const url of objectUrls.values())URL.revokeObjectURL(url);objectUrls.clear();currentAssetJob=jobId;
  }
  const assets=await store('assets','readonly',s=>s.index('job_id').getAll(jobId));
  for(const record of assets)if(!objectUrls.has(record.key))objectUrls.set(record.key,URL.createObjectURL(record.blob));
 }
 function asset(jobId,file){return objectUrls.get(jobId+'/'+file)||placeholder}
 async function runJob(job){
  runningJobs.add(job.id);heartbeat();let lastSave=0;
  const progress=(value,message)=>{job.progress=value;job.message=message;if(Date.now()-lastSave>1200){lastSave=Date.now();put('jobs',job).catch(console.error)}};
  try{
   job.status='running';job.message='Loading on-device models. The first visit also downloads the runtime.';await put('jobs',job);
   const manifest=await ensureWorker(),files=await sourceFiles(job);
   const result=await requestWorker('scan',{files,options:{...job.options,batch_size:8}},progress);
   const {scores,...main}=result;Object.assign(job,main);job.summary.checkpoint_sha256=manifest.checkpoint_sha256;
   for(const record of scores)await put('scores',{...record,key:job.id+'/'+record.file_id,job_id:job.id});
   const views=await requestWorker('images',{files,candidates:job.candidates,spacing:job.options.spacing_m,options:job.options},progress);
   job.candidates=views.candidates;await saveImages(job.id,views.images,(p,m)=>progress(.99,m));
   Object.assign(job,{status:'done',progress:1,message:'Detection complete. Ready for expert review.'});await put('jobs',job);
  }catch(error){Object.assign(job,{status:'error',message:error.message});await put('jobs',job).catch(console.error)}
  finally{runningJobs.delete(job.id);heartbeat()}
 }
 async function buildGallery(jobId,candidateId){
  const key=jobId+'/'+candidateId,state={status:'running',progress:0,message:'Preparing aligned channel images on this device.'};observationTasks.set(key,state);
  try{
   const job=await readJob(jobId),candidate=job.candidates.find(r=>r.candidate_id===candidateId);if(!candidate)throw Error('Candidate not found.');
   await ensureWorker();const files=await sourceFiles(job),gallery=await requestWorker('gallery',{candidate,files,spacing:job.options.spacing_m,options:job.options},(p,m)=>Object.assign(state,{progress:p*.8,message:m}));
   const {images,...data}=gallery;await saveImages(jobId,images,(p,m)=>Object.assign(state,{progress:.8+p*.2,message:m}));
   await withJobLock(jobId,async()=>{
    const latest=await readJob(jobId),row=latest.candidates.find(r=>r.candidate_id===candidateId);
    Object.assign(row,{observation_gallery:data.rows,channel_gallery:data.main_rows,swath_gallery_groups:data.groups,channel_gallery_warnings:data.warnings,alignment_audit:data.alignment_audit,observation_gallery_version:4});await put('jobs',latest);
   });
   Object.assign(state,{status:'done',progress:1,...data});
  }catch(error){Object.assign(state,{status:'error',message:error.message})}
 }
 const reviewKeys=['review_label','reviewer','notes','reviewed_at','review_history'];
 function updateReview(row,payload,origin='saved'){
  const label=payload.review_label??'unreviewed';if(!LABELS.has(label))throw Error('Invalid expert decision.');
  const previous={review_label:row.review_label||'unreviewed',notes:row.notes||'',reviewer:row.reviewer||''},values={review_label:label,notes:String(payload.notes??'').slice(0,5000),reviewer:String(payload.reviewer??row.reviewer??'').slice(0,100)};
  if(Object.keys(values).every(k=>values[k]===previous[k]))return {...row};
  const timestamp=new Date().toISOString(),history=[...(row.review_history||[])];
  if(!history.length)history.push({...previous,reviewed_at:row.reviewed_at||null,revision:0,origin:'baseline'});
  history.push({...values,reviewed_at:timestamp,revision:history.length,origin});return {...row,...values,reviewed_at:timestamp,review_history:history};
 }
 async function route(path,init){
  const url=new URL(path,location.href),parts=url.pathname.split('/').filter(Boolean),method=init?.method||'GET';
  const payload=method==='POST'&&typeof init.body==='string'?JSON.parse(init.body):{};
  if(url.pathname==='/api/state'){
   const jobs=await all('jobs');const history=[];
   for(const item of jobs){const job=await readJob(item.id);history.push({id:job.id,title:job.title,created:job.created,status:job.status,progress:job.progress,message:job.message,candidate_count:job.candidates.length})}
   return {token:'on-device',model:'Fairview v3',jobs:history.sort((a,b)=>b.created.localeCompare(a.created))};
  }
  if(url.pathname==='/api/uploads'&&method==='POST'){
   if(!(init.body instanceof Blob))throw Error('Choose an SGY file.');
   const name=url.searchParams.get('name')||'input.SGY',size=init.body.size;
   if(!/\.(sgy|segy)$/i.test(name)||size<3840||size>512*1024**2)throw Error('Use an SGY / SEGY file between 3,840 bytes and 512 MB.');
   const id=crypto.randomUUID().replaceAll('-','');await put('uploads',{id,name,size,file:init.body});return {id,name,size};
  }
  if(url.pathname==='/api/jobs'&&method==='POST'){
   const uploads=payload.uploads;if(!Array.isArray(uploads)||!uploads.length||uploads.length>GprCapacity.MAX_FILES)throw Error(`Choose 1–${GprCapacity.MAX_FILES} SGY files.`);
   const files=await Promise.all(uploads.map(id=>get('uploads',id)));if(files.some(f=>!f))throw Error('SGY file not found in browser storage.');
   const options=payload.options||{};
   if(!(options.threshold>0&&options.threshold<1&&options.step_m>=.1&&options.step_m<=2&&options.merge_m>=.5&&options.merge_m<=20&&options.spacing_m>=.001&&options.spacing_m<=2))throw Error('Invalid detection settings.');
   if(options.metal_mute&&(!Number.isFinite(options.metal_threshold)||options.metal_threshold<1||options.metal_threshold>10))throw Error('Metallic mute threshold must be between 1 and 10.');
   if(options.metal_mute&&!files.some(f=>options.metal_ranges_by_file?.[GprEngine.fileKey(f)]?.length))throw Error('Confirm at least one metallic trace range before applying mute.');
   const job={id:crypto.randomUUID().replaceAll('-',''),title:payload.title||files[0].name,created:new Date().toISOString(),runtime_tab_id:tabId,status:'queued',progress:0,message:'Waiting for on-device detection',input_files:files.map(({id,name,size})=>({id,name,size})),options:{...options,use_known:false,exclude_known:false},candidates:[],files:[],summary:{},warnings:[]};
   runningJobs.add(job.id);heartbeat();await put('jobs',job);runJob(job);return job;
  }
  if(parts[0]==='api'&&parts[1]==='jobs'&&parts[2]){
   const id=parts[2];let job=await readJob(id);
   if(parts.length===3){if(job.status==='done')await hydrateAssets(id);return job}
   const action=parts[3];
   if(action==='observations'){
    const candidateId=method==='POST'?payload.candidate_id:url.searchParams.get('candidate_id'),candidate=job.candidates.find(r=>r.candidate_id===candidateId);if(!candidate)throw Error('Candidate not found.');
    if(candidate.observation_gallery_version===4&&candidate.channel_gallery?.length){await hydrateAssets(id);return {status:'done',progress:1,rows:candidate.observation_gallery,main_rows:candidate.channel_gallery,groups:candidate.swath_gallery_groups||[],warnings:candidate.channel_gallery_warnings||[]}}
    const key=id+'/'+candidateId,state=observationTasks.get(key);
    if(method==='POST'&&(!state||state.status==='error')){buildGallery(id,candidateId);return {status:'queued',progress:0,message:'Preparing merged-hit channel views.'}}
    return state||{status:'idle',progress:0,message:'Waiting for channel images.'};
   }
   if(action==='export')return GprExports.makeExport(job,payload);
   if(action==='selection')return withJobLock(id,async()=>{
    const latest=await readJob(id),valid=new Set(latest.candidates.map(r=>r.candidate_id));
    if(!['all','manual'].includes(payload.mode)||!Array.isArray(payload.candidate_ids)||payload.candidate_ids.some(cid=>!valid.has(cid)))throw Error('Invalid export selection.');
    latest.export_selection={mode:payload.mode,candidate_ids:payload.mode==='manual'?[...new Set(payload.candidate_ids)].sort():[]};await put('jobs',latest);return {saved:true,selection:latest.export_selection};
   });
   if(action==='review')return withJobLock(id,async()=>{
    const latest=await readJob(id),index=latest.candidates.findIndex(r=>r.candidate_id===payload.candidate_id);if(index<0)throw Error('Candidate not found.');
    const updated=updateReview(latest.candidates[index],payload);latest.candidates[index]=updated;await put('jobs',latest);return {saved:true,candidate_id:updated.candidate_id,review:Object.fromEntries(reviewKeys.map(k=>[k,updated[k]??null]))};
   });
   if(action==='clear-reviews')return withJobLock(id,async()=>{
    if(payload.confirm_job_id!==id)throw Error('Confirm the current run before clearing reviews.');
    const latest=await readJob(id);if(latest.status!=='done')throw Error('Detection must finish before clearing reviews.');let count=0;
    latest.candidates=latest.candidates.map(r=>{const updated=updateReview(r,{review_label:'unreviewed',notes:'',reviewer:''},'cleared_all');if(updated.review_history!==r.review_history)count++;return updated});await put('jobs',latest);
    return {saved:true,cleared_count:count,reviews:latest.candidates.map(r=>({candidate_id:r.candidate_id,...Object.fromEntries(reviewKeys.map(k=>[k,r[k]??null]))}))};
   });
  }
  throw Error('This action is unavailable in the browser edition.');
 }
 window.fetch=async(input,init={})=>{
  const url=new URL(typeof input==='string'?input:input.url,location.href);
  if(url.origin!==location.origin||!url.pathname.startsWith('/api/'))return nativeFetch(input,init);
  try{
   const result=await route(url.href,init);
   if(result?.blob instanceof Blob)return new Response(result.blob,{headers:{'Content-Type':result.contentType,'Content-Disposition':`attachment; filename="${result.filename}"`}});
   return new Response(JSON.stringify(result),{headers:{'Content-Type':'application/json'}});
  }catch(error){return new Response(JSON.stringify({error:error.message}),{status:400,headers:{'Content-Type':'application/json'}})}
 };
 const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 async function downloadAtlas(id){
  const job=await readJob(id),assets=await store('assets','readonly',s=>s.index('job_id').getAll(id)),files={};
  for(const record of assets)files[record.file]=record.blob;
  const labels={similar:'Suspected leak',different:'No leak signal',uncertain:'Uncertain',unreviewed:'Pending review',manhole:'Possible manhole'};
  const cards=job.candidates.map(r=>{
   const main=(r.channel_gallery||[]).find(p=>p.primary)||r.panels.find(p=>p.primary),other=[...(r.channel_gallery||[]).filter(p=>!p.primary),...(r.swath_gallery_groups||[]).flatMap(g=>g.rows)];
   return `<article><h2>${escape(r.candidate_id)} · CH${r.channel??'—'}</h2><p>${escape(r.name)} · AI center trace ${r.trace_1based} · Model logit ${r.logit.toFixed(3)}</p><p>${escape(labels[r.review_label]||r.review_label)} · ${escape(r.notes)}</p><img src="${escape(main.file)}"><details><summary>16 m context and merged-hit channels</summary><img src="${escape(main.context_image||r.context_image)}">${other.map(p=>`<p>${escape(p.profile)} · CH${p.channel??'—'}</p><img src="${escape(p.file)}">`).join('')}</details></article>`;
  }).join('');
  files['report.html']='<!doctype html><html lang="en"><meta charset="utf-8"><title>AquaScope review atlas</title><style>body{font:15px system-ui;max-width:1100px;margin:30px auto;padding:15px}article{border-top:1px solid #ccc;padding:20px 0}img{width:100%}p{white-space:pre-wrap;overflow-wrap:anywhere}</style><h1>'+escape(job.title)+'</h1><p>On-device signal-similarity detection. Model ranks are not calibrated leak probabilities. Blue: aligned candidate position. Dashed green: AI center.</p>'+cards+'</html>';
  files['candidates.csv']=GprExports.csv(job.candidates);files['metadata.json']=JSON.stringify({summary:job.summary,files:job.files,options:job.options,warnings:job.warnings},null,2);
  const scores=await store('scores','readonly',s=>s.index('job_id').getAll(id));files['window_scores.json']=JSON.stringify(scores.map(({key,job_id,...record})=>record));
  download(await GprExports.zipStore(files),'gpr_'+id.slice(0,8)+'_review_atlas.zip');
 }
 function download(blob,filename){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=filename;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000)}
 document.addEventListener('click',event=>{const link=event.target.closest('#bundleBtn');if(!link)return;event.preventDefault();const id=new URL(link.href).pathname.split('/')[3];const text=link.textContent;link.style.pointerEvents='none';downloadAtlas(id).catch(error=>{const notice=document.getElementById('notice');notice.textContent=error.message;notice.hidden=false}).finally(()=>{link.style.pointerEvents='';link.textContent=text})});
 window.GprLocal={basePath:location.pathname,asset,downloadAtlas,metallicOperation,jobSourceFiles:async id=>sourceFiles(await readJob(id)),get running(){return runningJobs.size>0},ready:dbReady};
})();
