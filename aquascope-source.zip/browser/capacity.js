/* File count is an import guard, not a model input dimension. */
(function(root,factory){const value=factory();if(typeof module==='object'&&module.exports)module.exports=value;else root.GprCapacity=value})(typeof self!=='undefined'?self:globalThis,function(){
 'use strict';
 const MAX_FILES=1024,MAX_FILE_BYTES=512*1024**2;
 function formatBytes(value){if(!Number.isFinite(value))return 'Unknown';if(value>=1024**3)return (value/1024**3).toFixed(2)+' GB';return (value/1024**2).toFixed(1)+' MB'}
 function selectFiles(existing,incoming){
  const files=[],seen=new Set();let invalid=0,duplicates=0,overflow=0;
  for(const file of [...existing,...incoming]){
   if(!/\.(sgy|segy)$/i.test(file.name)||file.size<3840||file.size>MAX_FILE_BYTES){invalid++;continue}
   const key=JSON.stringify([file.name,file.size,file.lastModified]);if(seen.has(key)){duplicates++;continue}seen.add(key);
   if(files.length>=MAX_FILES){overflow++;continue}files.push(file);
  }
  const messages=[];if(invalid)messages.push(`${invalid} invalid, undersized or over-512 MB files were ignored.`);if(overflow)messages.push(`${overflow} additional files exceed the ${MAX_FILES}-file run limit. Import them in another run.`);
  return {files,invalid,duplicates,overflow,message:messages.join(' ')};
 }
 function evaluate(files,estimate){
  const total=files.reduce((sum,f)=>sum+f.size,0),valid=Number.isFinite(estimate?.quota)&&Number.isFinite(estimate?.usage)&&estimate.quota>0,available=valid?Math.max(0,estimate.quota-estimate.usage):null,reserve=Math.ceil(total*.25)+64*1024**2;
  return {count:files.length,total,available,planningBytes:total+reserve,status:available===null?'unknown':total>available?'insufficient':total+reserve>available?'tight':'ready'};
 }
 async function estimateStorage(){try{return await navigator.storage?.estimate?.()}catch{return null}}
 async function preflight(files){
  if(files.length>MAX_FILES)throw Error(`Choose at most ${MAX_FILES} SGY files per run.`);
  const result=evaluate(files,await estimateStorage());
  if(result.status==='insufficient')throw Error(`The selected SGYs need ${formatBytes(result.total)}, but this browser reports ${formatBytes(result.available)} available. Import a smaller batch or export your work and free site storage.`);
  return result;
 }
 return {MAX_FILES,MAX_FILE_BYTES,formatBytes,selectFiles,evaluate,estimateStorage,preflight};
});
