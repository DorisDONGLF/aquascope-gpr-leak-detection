/* Amplitude only suggests ranges. Only explicitly selected ranges can be muted. */
(function(){
 'use strict';
 const el=id=>document.getElementById(id),plans=new Map(),urls=[];
 let context=null,preview=null,working=false,generation=0;
 const key=GprEngine.fileKey;
 function threshold(){const n=Number(el('metalPreviewThreshold').value);if(!Number.isFinite(n)||n<1||n>10)throw Error('Suggestion threshold must be between 1 and 10.');return n}
 function selected(file){return context?.plans.get(key(file))||[]}
 function file(){return context?.files[Number(el('metalFileSelect').value)]}
 function refresh(){
  const count=files.reduce((sum,f)=>sum+(plans.get(key(f))?.length||0),0);
  el('previewMetal').disabled=!files.length||busy;
  el('metalEnabled').disabled=!count||busy;if(!count)el('metalEnabled').checked=false;
  el('metalPlanCount').textContent=count?`${count} selected range${count===1?'':'s'} across the selected SGY files.`:'No trace ranges selected.';
 }
 function options(){return {metal_mute:el('metalEnabled').checked,metal_threshold:Number(el('metalPreviewThreshold').value)||3,metal_ranges_by_file:Object.fromEntries(files.filter(f=>plans.get(key(f))?.length).map(f=>[key(f),plans.get(key(f)).map(r=>[...r])]))}}
 function setWorking(value){working=value;for(const id of ['updateMetalPreview','metalFileSelect','metalPreviewThreshold','addMetalRange','applyMetalPlan'])el(id).disabled=value;el('metalSuggestions').querySelectorAll('input').forEach(e=>e.disabled=value);el('metalSelected').querySelectorAll('button').forEach(e=>e.disabled=value);el('downloadMutedSgy').disabled=value||!preview?.report.muted_traces;el('downloadMetalLog').disabled=value||!preview}
 function error(e){el('metalError').textContent=e?.message||String(e)}
 function revoke(){for(const u of urls)URL.revokeObjectURL(u);urls.length=0}
 function image(id,blob){const u=URL.createObjectURL(blob);urls.push(u);el(id).src=u}
 function renderRanges(){
  const f=file(),ranges=selected(f),suggestions=preview.suggestions.ranges_1based_inclusive;
  el('metalSuggestions').replaceChildren();
  if(!suggestions.length)el('metalSuggestions').textContent='No ranges exceed this amplitude threshold.';
  for(const range of suggestions.slice(0,500)){
   const label=document.createElement('label'),check=document.createElement('input');check.type='checkbox';check.setAttribute('aria-label',`Mute suggested traces ${range[0]}–${range[1]}`);check.checked=ranges.some(r=>r[0]<=range[0]&&r[1]>=range[1]);
   check.onchange=async()=>{
    const now=selected(f),next=check.checked?[...now,range]:now.flatMap(r=>{if(r[1]<range[0]||r[0]>range[1])return [r];const a=[];if(r[0]<range[0])a.push([r[0],range[0]-1]);if(r[1]>range[1])a.push([range[1]+1,r[1]]);return a});
    context.plans.set(key(f),GprEngine.selectedMetalMask(preview.report.total_traces,next).report.ranges_1based_inclusive);await update();
   };label.append(check,document.createTextNode(`Traces ${range[0]}–${range[1]} · ${range[1]-range[0]+1} traces`));el('metalSuggestions').append(label);
  }
  if(suggestions.length>500)el('metalSuggestions').append(document.createTextNode(`Showing 500 of ${suggestions.length} ranges. Increase the threshold or enter exact ranges.`));
  el('metalSelected').replaceChildren();
  if(!ranges.length)el('metalSelected').textContent='None selected. Original data will be used.';
  ranges.forEach((range,i)=>{const row=document.createElement('div'),remove=document.createElement('button');row.className='metal-selected-row';remove.type='button';remove.className='text-button';remove.textContent='Remove';remove.setAttribute('aria-label',`Remove mute range ${range[0]}–${range[1]}`);remove.onclick=async()=>{context.plans.set(key(f),selected(f).filter((_,k)=>k!==i));await update()};row.append(document.createTextNode(`Traces ${range[0]}–${range[1]}`),remove);el('metalSelected').append(row)});
 }
 async function update(){
  if(working)return;const f=file();if(!f)return;let version;
  try{
   const t=threshold();version=++generation;setWorking(true);el('metalError').textContent='';el('metalStatus').textContent='Reading SGY and preparing full vertical before / after views…';
   const result=await GprLocal.metallicOperation('metal-preview',f,t,context.spacing,selected(f));if(version!==generation)return;
   preview=result;revoke();image('metalRawImage',result.raw);image('metalMutedImage',result.muted);
   el('metalStatus').textContent=`${result.suggestions.muted_traces.toLocaleString()} suggested traces · ${result.suggestions.ranges_1based_inclusive.length} suggested ranges · ${result.report.muted_traces.toLocaleString()} selected for mute (${result.report.muted_percent.toFixed(2)}% of ${result.report.total_traces.toLocaleString()} traces).`;
   renderRanges();
  }catch(e){preview=null;error(e);el('metalStatus').textContent='Preview could not be prepared.'}
  finally{setWorking(false)}
 }
 async function open(kind,job){
  if(working)return;
  try{
   const source=kind==='import'?files.map(f=>({id:key(f),name:f.name,size:f.size,file:f})):await GprLocal.jobSourceFiles(job.id);
   if(!source.length)return;
   context={kind,title:job?.title,files:source,plans:kind==='import'?new Map([...plans].map(([k,v])=>[k,v.map(r=>[...r])])):new Map(Object.entries(job.options?.metal_ranges_by_file||{})),spacing:kind==='import'?Number(el('spacing').value):job.options.spacing_m};
   el('metalFileSelect').replaceChildren(...source.map((f,i)=>new Option(f.name,String(i))));preview=null;el('metalError').textContent='';el('applyMetalPlan').textContent=kind==='import'?'Use selected ranges':'Prepare new detection';el('metalPreviewDialog').showModal();await update();
  }catch(e){notice(e.message)}
 }
 function download(blob,name){const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),60000)}
 function outputName(f){return f.name.replace(/-(\d+)(\.(?:sgy|segy))$/i,'_muted-$1$2').replace(/^(?!.*_muted-)(.*)(\.(?:sgy|segy))$/i,'$1_muted$2')}
 el('previewMetal').onclick=()=>open('import');el('closeMetal').onclick=()=>el('metalPreviewDialog').close();
 el('updateMetalPreview').onclick=update;el('metalFileSelect').onchange=update;el('metalPreviewThreshold').onchange=update;
 el('addMetalRange').onclick=async()=>{try{if(!preview)return;const ranges=GprEngine.selectedMetalMask(preview.report.total_traces,[...selected(file()),[Number(el('metalFirst').value),Number(el('metalLast').value)]]).report.ranges_1based_inclusive;context.plans.set(key(file()),ranges);await update()}catch(e){error(e)}};
 el('applyMetalPlan').onclick=()=>{
  for(const f of context.files)plans.set(key(f),selected(f));
  el('metalEnabled').checked=context.files.some(f=>selected(f).length);
  el('metalPreviewDialog').close();
  if(context.kind==='job'){files=context.files.map(f=>f.file instanceof File?f.file:new File([f.file],f.name,{lastModified:0}));el('spacing').value=context.spacing;el('taskTitle').value=(context.title+' · selected mute').slice(0,200);showFiles();el('importDialog').showModal()}
  refresh();
 };
 el('downloadMutedSgy').onclick=async()=>{
  try{setWorking(true);el('metalError').textContent='';const f=file(),result=await GprLocal.metallicOperation('metal-export',f,threshold(),context.spacing,selected(f));download(result.blob,outputName(f))}catch(e){error(e)}finally{setWorking(false)}
 };
 el('downloadMetalLog').onclick=()=>{if(preview)download(new Blob([JSON.stringify({file:file().name,...preview.report,suggestion_threshold:threshold(),suggested_ranges:preview.suggestions.ranges_1based_inclusive},null,2)],{type:'application/json'}),outputName(file())+'.mute.json')};
 el('metalPreviewDialog').addEventListener('close',()=>{generation++;revoke()});
 function renderRun(job){
  const box=el('metalRunSummary');box.hidden=!job?.input_files?.length;if(box.hidden)return;
  box.replaceChildren();const text=document.createElement('div'),title=document.createElement('strong'),note=document.createElement('p'),button=document.createElement('button');title.textContent=job.summary.metal_mute_enabled?`Selected metallic ranges muted · ${job.summary.muted_traces.toLocaleString()} traces`:'Original SGY · No metallic mute applied';note.textContent=job.summary.metal_mute_enabled?'B-scans and model inputs use the muted data. Originals and selected ranges are retained. Residual or edge detections can remain.':'Inspect suggested strong reflections, select confirmed metal ranges, and export or prepare a separate detection run.';text.append(title,note);button.className='secondary';button.textContent='Inspect / mute SGY';button.onclick=()=>open('job',job);box.append(text,button);
 }
 window.GprMetalUI={options,refresh,renderRun};refresh();
})();
