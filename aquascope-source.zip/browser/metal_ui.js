/* Original or muted detection; automatic mode computes a mask for every SGY. */
(function(){
 'use strict';
 const el=id=>document.getElementById(id),plans=new Map(),urls=[];
 let context=null,preview=null,working=false,generation=0;
 const key=GprEngine.fileKey;
 function threshold(){const n=Number(el('metalPreviewThreshold').value);if(!Number.isFinite(n)||n<1||n>10)throw Error('Suggestion threshold must be between 1 and 10.');return n}
 function selected(file){return context?.plans.get(key(file))||[]}
 function file(){return context?.files[Number(el('metalFileSelect').value)]}
 function refresh(){
  const count=files.reduce((sum,f)=>sum+(plans.get(key(f))?.length||0),0);
  el('previewMetal').disabled=!files.length||busy;
  el('metalEnabled').disabled=!count||busy;if(!count)el('metalEnabled').checked=false;
  for(const id of ['metalOriginal','metalAutomatic','metalAutoThreshold'])el(id).disabled=busy;
  el('metalPlanCount').textContent=el('metalEnabled').checked?`Edited mode: ${count} selected ranges. Files without edited ranges remain unchanged.`:'Automatic mode covers all input SGYs. No per-file confirmation is required.';
  el('startBtn').textContent=el('metalAutomatic').checked?(el('metalEnabled').checked?'Detect edited SGY →':'Mute all & detect →'):'Start detection →';
 }
 function options(){const t=Number(el('metalAutoThreshold').value);if(el('metalAutomatic').checked&&(!Number.isFinite(t)||t<1||t>10))throw Error('Auto-mute threshold must be between 1 and 10.');return {metal_mute:el('metalAutomatic').checked,metal_mode:el('metalAutomatic').checked?(el('metalEnabled').checked?'selected_ranges':'auto_amplitude'):'raw',metal_threshold:t,metal_ranges_by_file:Object.fromEntries(files.filter(f=>plans.get(key(f))?.length).map(f=>[key(f),plans.get(key(f)).map(r=>[...r])]))}}
 function setWorking(value){working=value;for(const id of ['updateMetalPreview','metalFileSelect','metalPreviewThreshold','addMetalRange','applyMetalPlan'])el(id).disabled=value;el('metalSuggestions').querySelectorAll('input').forEach(e=>e.disabled=value);el('metalSelected').querySelectorAll('button').forEach(e=>e.disabled=value);el('downloadMutedSgy').disabled=value||!preview?.report.muted_traces;el('downloadMetalLog').disabled=value||!preview}
 function error(e){el('metalError').textContent=e?.message||String(e)}
 function revoke(){for(const u of urls)URL.revokeObjectURL(u);urls.length=0}
 function image(id,blob){const u=URL.createObjectURL(blob);urls.push(u);el(id).src=u}
 function renderRanges(){
  const f=file(),ranges=selected(f),suggestions=preview.suggestions.ranges_1based_inclusive;
  el('metalSuggestions').replaceChildren();
  if(!suggestions.length)el('metalSuggestions').textContent='No ranges exceed this amplitude threshold.';
  for(const range of suggestions.slice(0,500)){
   const label=document.createElement('label'),check=document.createElement('input');check.type='checkbox';check.setAttribute('aria-label',`Mute suggested traces ${range[0]}–${range[1]}`);check.checked=ranges.some(r=>r[0]<=range[0]&&r[1]>=range[1]);
   check.onchange=async()=>{
    const now=selected(f),next=check.checked?[...now,range]:now.flatMap(r=>{if(r[1]<range[0]||r[0]>range[1])return [r];const a=[];if(r[0]<range[0])a.push([r[0],range[0]-1]);if(r[1]>range[1])a.push([range[1]+1,r[1]]);return a});
    context.edited=true;context.plans.set(key(f),GprEngine.selectedMetalMask(preview.report.total_traces,next).report.ranges_1based_inclusive);await update();
   };label.append(check,document.createTextNode(`Traces ${range[0]}–${range[1]} · ${range[1]-range[0]+1} traces`));el('metalSuggestions').append(label);
  }
  if(suggestions.length>500)el('metalSuggestions').append(document.createTextNode(`Showing 500 of ${suggestions.length} ranges. Increase the threshold or enter exact ranges.`));
  el('metalSelected').replaceChildren();
  if(!ranges.length)el('metalSelected').textContent='None selected. Original data will be used.';
  ranges.forEach((range,i)=>{const row=document.createElement('div'),remove=document.createElement('button');row.className='metal-selected-row';remove.type='button';remove.className='text-button';remove.textContent='Remove';remove.setAttribute('aria-label',`Remove mute range ${range[0]}–${range[1]}`);remove.onclick=async()=>{context.edited=true;context.plans.set(key(f),selected(f).filter((_,k)=>k!==i));await update()};row.append(document.createTextNode(`Traces ${range[0]}–${range[1]}`),remove);el('metalSelected').append(row)});
 }
 async function update(){
  if(working)return;const f=file();if(!f)return;let version;
  try{
   const t=threshold();version=++generation;setWorking(true);el('metalError').textContent='';el('metalStatus').textContent='Reading SGY and preparing full vertical before / after views…';
   const mode=context.mode==='auto_amplitude'&&!context.edited?'auto_amplitude':'selected_ranges';
   const result=await GprLocal.metallicOperation('metal-preview',f,t,context.spacing,selected(f),mode);if(version!==generation)return;
   if(mode==='auto_amplitude')context.plans.set(key(f),result.report.ranges_1based_inclusive);
   preview=result;revoke();image('metalRawImage',result.raw);image('metalMutedImage',result.muted);
   el('metalStatus').textContent=`${result.suggestions.muted_traces.toLocaleString()} suggested traces · ${result.suggestions.ranges_1based_inclusive.length} suggested ranges · ${result.report.muted_traces.toLocaleString()} selected for mute (${result.report.muted_percent.toFixed(2)}% of ${result.report.total_traces.toLocaleString()} traces).`;
   renderRanges();
  }catch(e){preview=null;error(e);el('metalStatus').textContent='Preview could not be prepared.'}
  finally{setWorking(false)}
 }
 async function open(kind,job){
  if(working)return;
  try{
   const source=kind==='import'?files.map(f=>({id:key(f),name:f.name,size:f.size,file:f})):await GprLocal.jobSourceFiles(job.id);
   if(!source.length)return;
   const settings=kind==='import'?options():job.options,mode=settings.metal_mute?(settings.metal_mode||'selected_ranges'):'auto_amplitude';
   context={kind,title:job?.title,mode,edited:false,files:source,plans:kind==='import'?new Map([...plans].map(([k,v])=>[k,v.map(r=>[...r])])):new Map(Object.entries(job.options?.metal_ranges_by_file||{})),spacing:kind==='import'?Number(el('spacing').value):job.options.spacing_m};
   el('metalPreviewThreshold').value=settings.metal_threshold??5;
   el('metalFileSelect').replaceChildren(...source.map((f,i)=>new Option(f.name,String(i))));preview=null;el('metalError').textContent='';el('applyMetalPlan').textContent=kind==='import'?'Use muted detection':'Prepare muted detection';el('metalPreviewDialog').showModal();await update();
  }catch(e){notice(e.message)}
 }
 function download(blob,name){const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),60000)}
 function outputName(f){return f.name.replace(/-(\d+)(\.(?:sgy|segy))$/i,'_muted-$1$2').replace(/^(?!.*_muted-)(.*)(\.(?:sgy|segy))$/i,'$1_muted$2')}
 el('previewMetal').onclick=()=>open('import');el('closeMetal').onclick=()=>el('metalPreviewDialog').close();
 for(const id of ['metalOriginal','metalAutomatic'])el(id).onchange=()=>{el('metalEnabled').checked=false;refresh()};el('metalEnabled').onchange=refresh;
 el('updateMetalPreview').onclick=update;el('metalFileSelect').onchange=update;el('metalPreviewThreshold').onchange=update;
 el('addMetalRange').onclick=async()=>{try{if(!preview)return;const ranges=GprEngine.selectedMetalMask(preview.report.total_traces,[...selected(file()),[Number(el('metalFirst').value),Number(el('metalLast').value)]]).report.ranges_1based_inclusive;context.edited=true;context.plans.set(key(file()),ranges);await update()}catch(e){error(e)}};
 el('applyMetalPlan').onclick=()=>{
  for(const f of context.files)plans.set(key(f),selected(f));
  el('metalEnabled').checked=(context.edited||context.mode==='selected_ranges')&&context.files.some(f=>selected(f).length);
  el('metalAutomatic').checked=true;el('metalAutoThreshold').value=threshold();
  el('metalPreviewDialog').close();
  if(context.kind==='job'){files=context.files.map(f=>f.file instanceof File?f.file:new File([f.file],f.name,{lastModified:0}));el('spacing').value=context.spacing;el('taskTitle').value=(context.title+' · muted detection').slice(0,200);showFiles();el('importDialog').showModal()}
  refresh();
 };
 el('downloadMutedSgy').onclick=async()=>{
  try{setWorking(true);el('metalError').textContent='';const f=file(),result=await GprLocal.metallicOperation('metal-export',f,threshold(),context.spacing,selected(f),context.mode==='auto_amplitude'&&!context.edited?'auto_amplitude':'selected_ranges');download(result.blob,outputName(f))}catch(e){error(e)}finally{setWorking(false)}
 };
 el('downloadMetalLog').onclick=()=>{if(preview)download(new Blob([JSON.stringify({file:file().name,...preview.report,suggestion_threshold:threshold(),suggested_ranges:preview.suggestions.ranges_1based_inclusive},null,2)],{type:'application/json'}),outputName(file())+'.mute.json')};
 el('metalPreviewDialog').addEventListener('close',()=>{generation++;revoke()});
 function renderRun(job){
  const box=el('metalRunSummary');box.hidden=!job?.input_files?.length;if(box.hidden)return;
  box.replaceChildren();const text=document.createElement('div'),title=document.createElement('strong'),note=document.createElement('p'),button=document.createElement('button'),automatic=job.summary.metal_mute_mode==='auto_amplitude';title.textContent=job.summary.metal_mute_enabled?`${automatic?'Automatic':'Edited-range'} mute · ${job.summary.muted_traces.toLocaleString()} traces`:'Original SGY · No metallic mute applied';note.textContent=job.summary.metal_mute_enabled?`${automatic?`All ${job.files.length} files processed at ${job.summary.metal_mute_threshold}× median. `:''}B-scans and model inputs use muted data. Originals are retained; residual or edge detections can remain.`:'Preview automatic mute recommendations, or prepare a separate muted detection run.';text.append(title,note);button.className='secondary';button.textContent='Inspect / mute SGY';button.onclick=()=>open('job',job);box.append(text,button);
  if(job.summary.metal_mute_enabled){
   const details=document.createElement('details'),summary=document.createElement('summary'),downloadLog=document.createElement('button');summary.textContent=`Per-file mute report · ${job.files.length} files`;details.append(summary);details.className='metal-batch-report';
   const reports=job.files.map(f=>({name:f.name,...(f.metal_mute||{selection_mode:'raw',muted_traces:0,total_traces:f.traces,ranges_1based_inclusive:[]})}));
   details.ontoggle=()=>{if(!details.open||details.dataset.ready)return;details.dataset.ready='yes';const table=document.createElement('table'),head=document.createElement('tr');for(const label of ['SGY file','Muted traces','Trace ranges']){const cell=document.createElement('th');cell.textContent=label;head.append(cell)}table.append(head);for(const f of reports){const row=document.createElement('tr');for(const value of [f.name,`${f.muted_traces} / ${f.total_traces}`,f.ranges_1based_inclusive.length?f.ranges_1based_inclusive.slice(0,5).map(r=>r.join('–')).join(', ')+(f.ranges_1based_inclusive.length>5?' …':''):'None']){const cell=document.createElement('td');cell.textContent=value;row.append(cell)}table.append(row)}details.append(table)};
   downloadLog.type='button';downloadLog.className='text-button';downloadLog.textContent='Download all mute ranges';downloadLog.onclick=()=>download(new Blob([JSON.stringify({job_id:job.id,mode:job.summary.metal_mute_mode||'selected_ranges',threshold:job.summary.metal_mute_threshold??null,manhole_classification:false,files:reports},null,2)],{type:'application/json'}),'gpr_'+job.id.slice(0,8)+'_mute_ranges.json');text.append(downloadLog,details);
  }
 }
 window.GprMetalUI={options,refresh,renderRun};refresh();
})();
