# Horizontal Localizer v1

`localizer_v1.pt` contains the original trained horizontal localizer weights. Inference architecture is defined in server/model_runtime.py. It estimates a horizontal center, not an anomaly boundary or leak probability.
