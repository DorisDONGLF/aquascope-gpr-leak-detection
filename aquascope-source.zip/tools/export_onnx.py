"""Export the unchanged trained detector/localizer and verify CPU parity."""
from pathlib import Path
import argparse
import hashlib
import json
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dependency-dir', action='append', default=[])
    args = parser.parse_args()
    for directory in args.dependency_dir:
        sys.path.insert(0, directory)
    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root / 'server'))
    import torch
    import numpy as np
    import onnx
    import onnxruntime as ort
    from model_runtime import PresenceCNN, PooledLinear, Localizer

    torch.set_num_threads(2)
    selection = torch.load(root / 'model_v3' / 'selected_model.pt', map_location='cpu', weights_only=False)
    presence_path = root / 'model_v3' / (selection['model_name'] + '.pt')
    localizer_path = root / 'model_v1' / 'localizer_v1.pt'
    presence = PresenceCNN() if selection['model_name'] == 'cnn' else PooledLinear()
    localizer = Localizer()
    presence.load_state_dict(torch.load(presence_path, map_location='cpu', weights_only=False)['state_dict'])
    localizer.load_state_dict(torch.load(localizer_path, map_location='cpu', weights_only=False)['state_dict'])
    output = root / 'browser' / 'models'
    output.mkdir(parents=True, exist_ok=True)
    manifest = dict(version=1, input_shape=[None, 1, 128, 193], threshold=float(selection['threshold']),
                    checkpoint_sha256=hashlib.sha256(presence_path.read_bytes()).hexdigest(),
                    localizer_checkpoint_sha256=hashlib.sha256(localizer_path.read_bytes()).hexdigest(),
                    normalization='bilinear resize, align_corners=False; float32 abs p99 clip [-1,1]',
                    quantized=False, opset=17, runtime_web_version='1.31.1')
    reports = []
    for name, model, filename, output_name in [('presence', presence, 'presence_v3.onnx', 'logit'),
                                               ('localizer', localizer, 'localizer_v1.onnx', 'horizontal_logits')]:
        model.eval()
        example = torch.zeros(2, 1, 128, 193)
        path = output / filename
        torch.onnx.export(model, example, str(path), input_names=['input'], output_names=[output_name],
                          dynamic_axes={'input': {0: 'batch'}, output_name: {0: 'batch'}},
                          opset_version=17, dynamo=False, do_constant_folding=True)
        graph = onnx.load(str(path))
        onnx.checker.check_model(graph)
        session = ort.InferenceSession(str(path), providers=['CPUExecutionProvider'])
        rng = np.random.default_rng(20261028)
        differences = []
        argmax_identical = True
        for batch in [1, 2, 8]:
            values = rng.uniform(-1, 1, (batch, 1, 128, 193)).astype('float32')
            with torch.no_grad():
                expected = model(torch.from_numpy(values)).numpy()
            actual = session.run(None, {'input': values})[0]
            differences.append(float(np.max(np.abs(actual - expected))))
            np.testing.assert_allclose(actual, expected, atol=1e-4, rtol=1e-4)
            if name == 'localizer':
                argmax_identical &= bool(np.array_equal(actual.argmax(1), expected.argmax(1)))
        assert argmax_identical
        manifest[name] = dict(file=filename, sha256=hashlib.sha256(path.read_bytes()).hexdigest(), bytes=path.stat().st_size)
        reports.append(dict(model=name, batches=[1, 2, 8], max_abs_error=max(differences),
                            localizer_argmax_identical=argmax_identical if name == 'localizer' else None,
                            operations=sorted({node.op_type for node in graph.graph.node})))
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    report = dict(onnx_version=onnx.__version__, onnxruntime_version=ort.__version__, torch_version=torch.__version__,
                  unchanged_checkpoint=True, random_input_parity=reports)
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
