"""Package only the explicitly publishable source tree, never survey data."""
from pathlib import Path
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DIRECTORIES = ['browser', 'docs', 'tools', 'server', 'model_v1', 'model_v3']
FILES = ['README.md', 'DEPLOYMENT.md', 'VALIDATION.md', 'THIRD_PARTY_NOTICES.md',
         'requirements.txt', 'Dockerfile', '.dockerignore', '.gitignore']


def main():
    paths = [ROOT / name for name in FILES]
    for name in DIRECTORIES:
        paths += [p for p in (ROOT / name).rglob('*') if p.is_file()
                  and not {'__pycache__', '.git', 'runs', 'uploads', 'data'}.intersection(p.relative_to(ROOT).parts)
                  and not any(part.startswith('test_export_tmp_') for part in p.parts)
                  and p.suffix.lower() not in {'.pyc', '.sgy', '.segy', '.csv', '.xlsx'}]
    archive = ROOT / 'aquascope-source.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in sorted(set(paths)):
            z.write(path, path.relative_to(ROOT).as_posix())
    print(json.dumps({'archive': str(archive), 'files': len(set(paths)),
                      'bytes': archive.stat().st_size, 'raw_survey_files': 0}, indent=2))


if __name__ == '__main__':
    main()
