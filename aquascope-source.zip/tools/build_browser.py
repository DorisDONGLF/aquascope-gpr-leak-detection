"""Build normal static assets and a single-file GitHub Pages application."""
from pathlib import Path
import base64
import json
import re
import shutil

ROOT=Path(__file__).resolve().parents[1]
BROWSER=ROOT/'browser'
SOURCE=ROOT/'server'/'static'


def main():
    BROWSER.mkdir(exist_ok=True)
    (BROWSER/'vendor').mkdir(exist_ok=True)
    for name in ['proj4.js','proj4-LICENSE.md']:
        shutil.copy2(SOURCE/'vendor'/name,BROWSER/'vendor'/name)
    for name in ['style.css','observations.js','candidate_map.js','geo.js']:
        shutil.copy2(SOURCE/name,BROWSER/name)
    script=(SOURCE/'app.js').read_text(encoding='utf-8')
    old="function asset(path){return '/runs/'+active.id+'/'+path}"
    assert old in script
    script=script.replace(old,"function asset(path){return GprLocal.asset(active.id,path)}")
    assert "asset:path=>'/runs/'+jobId+'/'+path" in script
    script=script.replace("asset:path=>'/runs/'+jobId+'/'+path","asset:path=>GprLocal.asset(jobId,path)")
    script=script.replace("'/?job='","GprLocal.basePath+'?job='")
    script=script.replace('Saved to workspace','Saved in this browser').replace('Saved locally','Saved in this browser')
    script=script.replace('Uploading ${i+1}','Saving file ${i+1}')
    script=script.replace("if(dirty||selectionDirty){e.preventDefault()","if(dirty||selectionDirty||GprLocal.running){e.preventDefault()")
    (BROWSER/'ui.js').write_text(script,encoding='utf-8')

    # Browser storage uses ISO UTC timestamps; show their timezone explicitly.
    script=(BROWSER/'ui.js').read_text(encoding='utf-8').replace(".replace(/\\+08:00$/,' (Hong Kong time)')",".replace(/\\+08:00$/,' (Hong Kong time)').replace(/Z$/,' UTC')")
    (BROWSER/'ui.js').write_text(script,encoding='utf-8')
    observations=(BROWSER/'observations.js').read_text(encoding='utf-8')
    observations=observations.replace("legend.textContent=reference?", "legend.textContent=row.alignment_version!==4?'Blue: same-file candidate trace · Dashed green: AI center':reference?")
    (BROWSER/'observations.js').write_text(observations,encoding='utf-8')
    maps=(BROWSER/'candidate_map.js').read_text(encoding='utf-8')
    maps=maps.replace('this.satellite=true;',"this.satellite=true;this.enabled=false;\n    try{this.enabled=localStorage.getItem('gpr-browser-map-enabled')==='yes'}catch(_){}")
    maps=maps.replace('<div class="map-mode">','<button type="button" id="enableBrowserMap" class="text-button">Show map</button><div class="map-mode">')
    maps=maps.replace("this.frame=root.querySelector('iframe');", "root.querySelector('#enableBrowserMap').onclick=()=>{this.enabled=true;try{localStorage.setItem('gpr-browser-map-enabled','yes')}catch(_){}this.loadMap()};\n    this.frame=root.querySelector('iframe');")
    maps=maps.replace("if(!this.point)return;", "if(!this.point)return;\n    this.root.querySelector('#enableBrowserMap').hidden=this.enabled;\n    if(!this.enabled){this.frame.hidden=true;this.placeholder.hidden=false;this.placeholder.textContent='Show map to share this candidate location with Google Maps.';return}")
    (BROWSER/'candidate_map.js').write_text(maps,encoding='utf-8')

    html=(SOURCE/'index.html').read_text(encoding='utf-8')
    html=html.replace('href="/"','href="./"').replace('href="/style.css"','href="./style.css"')
    html=html.replace('Browser workspace','On-device workspace').replace('Local workspace','On-device workspace')
    html=html.replace('Server processing','Runs in your browser').replace('Local processing','Runs in your browser')
    html=html.replace('Detections, images and reviews are stored in this browser workspace','SGY files, images and reviews stay in this browser')
    html=html.replace('Import SGY data and run the signal similarity model.','Choose SGY files and run the model on this computer.')
    html=html.replace('Review full vertical B-scans, mark candidates and export your results.','Review full vertical B-scans, mark candidates and export your results. Files and reviews stay in this browser; clearing site storage removes them.')
    html=re.sub(r'<script src="[^"]+"></script>','',html)
    sources=['vendor/proj4.js','geo.js','candidate_map.js','engine.js','renderer.js','exports.js','local_backend.js','observations.js','ui.js']
    html=html.replace('</body>', ''.join(f'<script src="./{name}"></script>' for name in sources)+'</body>')
    (BROWSER/'index.html').write_text(html,encoding='utf-8')

    # The published application needs one HTML file plus the pinned CDN runtime.
    # Runtime/models never receive the user's SGY, coordinates or review notes.
    config=dict(manifest=json.loads((BROWSER/'models'/'manifest.json').read_text(encoding='utf-8')),
                runtimeBase='https://cdn.jsdelivr.net/npm/onnxruntime-web@1.31.1/dist/',
                workerSource='\n'.join((BROWSER/name).read_text(encoding='utf-8') for name in ['engine.js','renderer.js','worker.js']))
    config['models']={key:base64.b64encode((BROWSER/'models'/config['manifest'][key]['file']).read_bytes()).decode('ascii') for key in ['presence','localizer']}
    standalone=html.replace('<link rel="stylesheet" href="./style.css">','<style>'+(BROWSER/'style.css').read_text(encoding='utf-8')+'</style>')
    config_text=json.dumps(config,ensure_ascii=True).replace('</','<\\/')
    inline='<script>window.GPR_BROWSER_BUNDLE='+config_text+';</script>'
    for name in sources:
        code=(BROWSER/name).read_text(encoding='utf-8').replace('</script','<\\/script')
        standalone=standalone.replace(f'<script src="./{name}"></script>','<script>'+code+'</script>')
    standalone=standalone.replace('<script>/* Source XY:',inline+'<script>/* Source XY:',1) if '<script>/* Source XY:' in standalone else standalone.replace('</head>',inline+'</head>',1)
    docs=ROOT/'docs';docs.mkdir(exist_ok=True)
    (docs/'index.html').write_text(standalone,encoding='utf-8')
    (docs/'.nojekyll').write_text('',encoding='utf-8')
    (docs/'README.md').write_text('# GitHub Pages application\n\nOpen index.html through an HTTPS or localhost web server. The detector and localizer are embedded as ONNX bytes. A pinned ONNX Runtime Web 1.31.1 runtime is loaded from jsDelivr; user SGY files and reviews are processed and stored on-device. Google Maps is optional and sends the selected location to Google only after Show map is enabled.\n\nSource modules are in browser/; rebuild with python tools/build_browser.py.\n',encoding='utf-8')
    print(json.dumps(dict(static_entry=str(BROWSER/'index.html'),pages_entry=str(docs/'index.html'),pages_bytes=(docs/'index.html').stat().st_size,models_embedded=True,server_api_required=False),indent=2))


if __name__=='__main__':
    main()
